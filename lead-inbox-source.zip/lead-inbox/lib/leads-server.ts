import { z } from "zod";
import { leadInput, aiOutput, AI_SCHEMA, AI_INSTRUCTIONS, STATUSES, type Lead } from "./leads-domain.ts";
import {restoreProxyRequest} from "./lead-proxy.mjs";

export type AppEnv = {
  DB?: D1Database; PIN_HASH?: string; SESSION_SECRET?: string; LEAD_PROXY_SECRET?: string;
  OPENAI_API_KEY?: string; OPENAI_MODEL?: string;
  AI_PROVIDER?: string; GROQ_API_KEY?: string; GROQ_MODEL?: string;
  TELEGRAM_BOT_TOKEN?: string; TELEGRAM_CHAT_ID?: string;
  RESEND_API_KEY?: string; EMAIL_FROM?: string; EMAIL_TO?: string;
};
type Integrations = {
  aiKey: string; aiModel: string; notificationProvider: "telegram";
  aiProvider: "openai" | "groq"; groqKey: string; groqModel: string;
  telegramToken: string; telegramChatId: string;
  telegramChatTitle?: string; telegramChatType?: string; telegramVerifiedAt?: number;
  messengerEnabled: boolean; emailEnabled: boolean; customerEmailEnabled: boolean; resendKey: string; emailFrom: string; emailTo: string;
};
class HttpError extends Error {
  status: number; extra: Record<string, unknown>;
  constructor(status: number, message: string, extra: Record<string, unknown> = {}) { super(message); this.status=status; this.extra=extra; }
}
const encoder = new TextEncoder(), cookieName = "lead_session", sessionAge = 12*60*60;
export async function hash(value: string) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",encoder.encode(value))),b=>b.toString(16).padStart(2,"0")).join("");
}
function randomToken() { return Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,"0")).join(""); }
function db(env: AppEnv) { if(!env.DB) throw new HttpError(503,"Datubāze īslaicīgi nav pieejama."); return env.DB; }
function secret(env: AppEnv) { if(!env.SESSION_SECRET||!env.PIN_HASH) throw new HttpError(503,"Piekļuve vēl nav konfigurēta."); return env.SESSION_SECRET; }
export function json(data: unknown, status=200, headers: Record<string,string>={}) {
  return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff",...headers}});
}
async function body(request: Request) {
  if(!request.headers.get("content-type")?.includes("application/json")) throw new HttpError(415,"Nepieciešami JSON dati.");
  if(Number(request.headers.get("content-length")||0)>16000) throw new HttpError(413,"Pieteikums ir pārāk liels.");
  const text=await request.text();
  if(encoder.encode(text).length>16000) throw new HttpError(413,"Pieteikums ir pārāk liels.");
  try { return JSON.parse(text); } catch { throw new HttpError(400,"Neizdevās nolasīt pieteikumu."); }
}
function checkOrigin(request: Request) {
  const origin=request.headers.get("origin");
  if((origin&&origin!==new URL(request.url).origin)||request.headers.get("sec-fetch-site")==="cross-site") throw new HttpError(403,"Šis pieprasījums nav atļauts.");
}
async function rateLimit(request: Request, env: AppEnv, scope: string, limit: number, windowMs: number) {
  const now=Date.now(),ip=request.headers.get("cf-connecting-ip")||"local";
  const key=`${scope}:${await hash(`${env.SESSION_SECRET}:${ip}`)}:${Math.floor(now/windowMs)}`;
  const result=await db(env).prepare("INSERT INTO rate_limits (key,hits,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET hits=hits+1 RETURNING hits").bind(key,now+windowMs).first<{hits:number}>();
  if((result?.hits||0)>limit) {
    const retryAfterSeconds=Math.max(1,Math.ceil(((Math.floor(now/windowMs)+1)*windowMs-now)/1000));
    throw new HttpError(429,"Pārāk daudz mēģinājumu. Lūdzu, pamēģini vēlāk.",{retryAfterSeconds});
  }
}
async function session(request: Request,env: AppEnv) {
  const token=request.headers.get("cookie")?.match(/(?:^|;\s*)lead_session=([a-f0-9]{64})(?:;|$)/)?.[1];
  if(!token) return false;
  return Boolean(await db(env).prepare("SELECT token_hash FROM sessions WHERE token_hash=? AND expires_at>?").bind(await hash(token),Date.now()).first());
}
async function authorize(request: Request,env: AppEnv) { if(!await session(request,env)) throw new HttpError(401,"Ievadi PIN, lai atvērtu inbox."); }
async function encryptionKey(env: AppEnv) {
  return crypto.subtle.importKey("raw",await crypto.subtle.digest("SHA-256",encoder.encode(secret(env))),"AES-GCM",false,["encrypt","decrypt"]);
}
export async function seal(value: unknown,env: AppEnv) {
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ciphertext=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv},await encryptionKey(env),encoder.encode(JSON.stringify(value))));
  const bytes=new Uint8Array(iv.length+ciphertext.length); bytes.set(iv); bytes.set(ciphertext,iv.length);
  return btoa(String.fromCharCode(...bytes));
}
export async function unseal(value: string,env: AppEnv) {
  const bytes=Uint8Array.from(atob(value),v=>v.charCodeAt(0));
  return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:"AES-GCM",iv:bytes.slice(0,12)},await encryptionKey(env),bytes.slice(12))));
}
export async function getIntegrations(env: AppEnv): Promise<Integrations> {
  const stored=await db(env).prepare("SELECT sealed FROM settings WHERE id='integrations'").first<{sealed:string}>();
  const saved=stored?await unseal(stored.sealed,env) as Partial<Integrations>:{};
  return {aiKey:saved.aiKey||env.OPENAI_API_KEY||"",aiModel:saved.aiModel||env.OPENAI_MODEL||"gpt-4.1-mini",
    aiProvider:saved.aiProvider||(env.AI_PROVIDER==="groq"||(!env.AI_PROVIDER&&env.GROQ_API_KEY)?"groq":"openai"),groqKey:saved.groqKey||env.GROQ_API_KEY||"",groqModel:saved.groqModel||env.GROQ_MODEL||"openai/gpt-oss-20b",
    notificationProvider:"telegram",
    telegramToken:saved.telegramToken||env.TELEGRAM_BOT_TOKEN||"",telegramChatId:saved.telegramChatId||env.TELEGRAM_CHAT_ID||"",
    telegramChatTitle:saved.telegramChatTitle||"",telegramChatType:saved.telegramChatType||"",telegramVerifiedAt:saved.telegramVerifiedAt||0,
    messengerEnabled:saved.messengerEnabled??true,emailEnabled:saved.emailEnabled??Boolean(env.RESEND_API_KEY&&env.EMAIL_FROM&&env.EMAIL_TO),customerEmailEnabled:saved.customerEmailEnabled??true,
    resendKey:saved.resendKey||env.RESEND_API_KEY||"",emailFrom:saved.emailFrom??env.EMAIL_FROM??"",emailTo:saved.emailTo??env.EMAIL_TO??""};
}
function selectedAiModel(config:Integrations){return config.aiProvider==="groq"?config.groqModel:config.aiModel;}
function recordedAiModel(config:Integrations){return config.aiProvider==="groq"?`Groq · ${config.groqModel}`:config.aiModel;}
function readiness(config: Integrations) {
  const messengerReady=Boolean(config.telegramToken&&config.telegramChatId);
  const emailReady=Boolean(config.resendKey&&config.emailFrom&&config.emailTo);
  return {ai:Boolean(config.aiProvider==="groq"?config.groqKey:config.aiKey),notifications:(config.messengerEnabled||config.emailEnabled)&&(!config.messengerEnabled||messengerReady)&&(!config.emailEnabled||emailReady),
    notificationProvider:config.notificationProvider,aiProvider:config.aiProvider,aiModel:selectedAiModel(config),messengerEnabled:config.messengerEnabled,emailEnabled:config.emailEnabled,messengerReady,emailReady,
    customerEmailEnabled:config.customerEmailEnabled,customerEmailReady:Boolean(config.resendKey&&config.emailFrom&&!isTestSender(config)),emailTestSender:isTestSender(config)};
}
function isTestSender(config:Integrations){return config.emailFrom.toLowerCase().endsWith("@resend.dev");}
function confirmationAvailability(config:Integrations,email:string){
  if(!config.customerEmailEnabled)return "disabled";
  if(!config.resendKey||!config.emailFrom||isTestSender(config)&&email.toLowerCase()!==config.emailTo.toLowerCase())return "unavailable";
  return "pending";
}
async function serviceFetch(url:string,options:RequestInit,label:string){
  try{
    // Workers supports manual/follow, but not the Fetch standard's error mode.
    // Return redirects as unsuccessful responses without forwarding credentials.
    return await fetch(url,{...options,redirect:"manual"});
  }catch(error){
    if(error instanceof Error&&(error.name==="AbortError"||error.name==="TimeoutError"))throw error;
    throw new Error(`${label} savienojumu ar servisu neizdevās izveidot. Jāpārbauda servera savienojums un jāmēģina vēlreiz.`);
  }
}
export async function evaluate(lead: Pick<Lead,"company"|"industry"|"revenue"|"goal">,config: Integrations) {
  if(config.aiProvider==="groq")return evaluateGroq(lead,config);
  const response=await serviceFetch("https://api.openai.com/v1/responses",{method:"POST",headers:{Authorization:`Bearer ${config.aiKey}`,"Content-Type":"application/json"},
    body:JSON.stringify({model:config.aiModel,store:false,instructions:AI_INSTRUCTIONS,input:JSON.stringify({company:lead.company,industry:lead.industry,monthlyRevenue:lead.revenue,goal:lead.goal}),text:{format:{type:"json_schema",name:"lead_assessment",strict:true,schema:AI_SCHEMA}},max_output_tokens:600}),
    signal:AbortSignal.timeout(17000)},"AI");
  if(!response.ok){
    const raw=await response.text();
    let data:{error?:{code?:string;type?:string;message?:string}}|null=null;
    try{data=JSON.parse(raw);}catch{/* A gateway may return HTML instead of an OpenAI API error. */}
    const code=data?.error?.code||data?.error?.type;
    const knownCode=["insufficient_quota","credit_balance_exhausted","organization_spend_limit_exceeded","project_spend_limit_exceeded","organization_usage_limit_exceeded","slow_down","rate_limit_exceeded","invalid_api_key","model_not_found","billing_hard_limit_reached","billing_not_active","quota_exceeded"].includes(code||"")?code:"unknown";
    const hint=(typeof data?.error?.message==="string"?data.error.message:raw).toLowerCase();
    const billingHint=/billing|payment method|credits|quota|balance/.test(hint),zeroLimit=/limit\s*:?\s*0\b/.test(hint);
    // Log only classified metadata, never provider messages, keys or headers.
    console.error("Lead Inbox AI provider response",JSON.stringify({status:response.status,code:knownCode,json:response.headers.get("content-type")?.includes("json")||false,structured:Boolean(data?.error),billingHint,zeroLimit,rateHint:/rate limit|too many requests/.test(hint),gatewayHint:/cloudflare|access denied|temporarily banned|error code:\s*1015/.test(hint)}));
    if(code==="credit_balance_exhausted")throw new Error("AI API kredīts ir beidzies (429, credit_balance_exhausted). Papildini kredītu OpenAI API Billing sadaļā.");
    if(code==="organization_spend_limit_exceeded"||code==="project_spend_limit_exceeded")throw new Error(`AI organizācijas vai projekta tēriņu limits ir sasniegts (429, ${code}). Pārbaudi OpenAI API Limits.`);
    if(code==="organization_usage_limit_exceeded")throw new Error("AI organizācijai piešķirtais API lietojuma limits ir sasniegts (429, organization_usage_limit_exceeded). Jāpieprasa lielāks limits OpenAI.");
    if(code==="slow_down")throw new Error("AI pieprasījumu ātrums pieaudzis pārāk strauji (429, slow_down). Uzgaidi un mēģini vēlreiz.");
    if(code==="insufficient_quota")throw new Error(`AI API kredīts nav pieejams vai sasniegts tēriņu limits (${response.status}, insufficient_quota). Pārbaudi OpenAI API Billing.`);
    if(response.status===401)throw new Error("AI atslēga nav derīga vai tai nav piekļuves (401). Pārbaudi OpenAI projekta atslēgu.");
    if(code==="model_not_found"||response.status===403)throw new Error(`AI modelim vai projektam nav piekļuves (${response.status}). Pārbaudi modeli un atslēgas tiesības.`);
    if(response.status===429&&code==="rate_limit_exceeded")throw new Error(billingHint||zeroLimit?"AI projekta pieprasījumu limits ir sasniegts vai ir 0 (429, rate_limit_exceeded). Pārbaudi OpenAI API Billing un Limits.":"AI pieprasījumu ātruma limits ir sasniegts (429, rate_limit_exceeded). Uzgaidi un mēģini vēlreiz.");
    if(response.status===429)throw new Error("AI serviss noraidīja pieprasījumu (429), bet nenorādīja atpazīstamu iemeslu. Jāpārbauda OpenAI API kvota un savienojuma ierobežojumi.");
    throw new Error(`AI serviss atbildēja ar ${response.status}. Pārbaudi atslēgu, modeli un API kredītu.`);
  }
  const data=await response.json() as {output?:{content?:{type:string;text?:string}[]}[]};
  const text=data.output?.flatMap(v=>v.content||[]).filter(v=>v.type==="output_text").map(v=>v.text||"").join("");
  if(!text) throw new Error("AI neatgrieza vērtējumu. Mēģini vēlreiz.");
  return aiOutput.parse(JSON.parse(text));
}
async function evaluateGroq(lead:Pick<Lead,"company"|"industry"|"revenue"|"goal">,config:Integrations){
  const response=await serviceFetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${config.groqKey}`,"Content-Type":"application/json"},body:JSON.stringify({
    model:config.groqModel,messages:[{role:"system",content:AI_INSTRUCTIONS},{role:"user",content:JSON.stringify({company:lead.company,industry:lead.industry,monthlyRevenue:lead.revenue,goal:lead.goal})}],
    response_format:{type:"json_schema",json_schema:{name:"lead_assessment",strict:true,schema:AI_SCHEMA}},max_completion_tokens:1200,temperature:0.2,...(config.groqModel.startsWith("openai/gpt-oss-")?{reasoning_effort:"low"}:{}),
  }),signal:AbortSignal.timeout(17000)},"AI Groq");
  if(!response.ok){
    if(response.status===401)throw new Error("AI Groq atslēga nav derīga (401). Pārbaudi saglabāto Groq API atslēgu.");
    if(response.status===429)throw new Error("AI Groq kvotas limits ir sasniegts (429). Sagaidi kvotas atjaunošanos un atkārto apstrādi; pieteikums paliek saglabāts.");
    if(response.status===403||response.status===404)throw new Error(`AI Groq modelim nav piekļuves (${response.status}). Pārbaudi izvēlēto modeli un konta tiesības.`);
    throw new Error(`AI Groq serviss atbildēja ar ${response.status}. Pārbaudi savienojumu un modeļa iestatījumus.`);
  }
  const data=await response.json() as {choices?:{message?:{content?:string|null};finish_reason?:string}[]};
  const choice=data.choices?.[0];
  if(!choice?.message?.content||choice.finish_reason==="length")throw new Error("AI Groq atbilde bija nepilnīga. Atkārto apstrādi.");
  let value:unknown;try{value=JSON.parse(choice.message.content);}catch{throw new Error("AI Groq neatgrieza derīgu vērtējumu. Atkārto apstrādi.");}
  const parsed=aiOutput.safeParse(value);if(!parsed.success)throw new Error("AI Groq vērtējums neatbilst prasītajai formai. Atkārto apstrādi.");
  return parsed.data;
}
type TelegramChat={id:number;type?:string;title?:string;first_name?:string};
type TelegramResponse<T>={ok?:boolean;result?:T;error_code?:number;description?:string;parameters?:{migrate_to_chat_id?:number;retry_after?:number}};
function telegramError(status:number,data:TelegramResponse<unknown>,discovery=false){
  // Classify provider text locally; never return raw messages or token-bearing URLs.
  const code=data.error_code||status,description=(data.description||"").toLowerCase();
  if(code===401||code===404)return new Error(`Telegram bota atslēga nav derīga (${code}). Pārbaudi atslēgu no BotFather.`);
  if(code===403)return new Error("Telegram botam nav tiesību sūtīt ziņas (403). Pievieno botu izvēlētajai grupai un atļauj tam sūtīt ziņas; privātā čatā nospied Start un atbloķē botu.");
  if(code===409&&discovery)return new Error("Telegram grupu meklēšana nav pieejama (409), jo botam jau darbojas cits saņēmējs vai webhook. Ievadi grupas Chat ID manuāli; paziņojumu sūtīšana var turpināt darboties.");
  if(code===429){const seconds=Math.min(3600,Math.max(1,Number(data.parameters?.retry_after)||60));return new Error(`Telegram sūtīšanas limits ir sasniegts (429). Mēģini vēlreiz pēc ${seconds} sekundēm.`);}
  if(code===400&&/chat not found|chat_id|peer_id/.test(description))return new Error("Telegram grupa nav atrasta (400). Pievieno botu grupai, grupā nosūti /start un spied “Atrast grupu”. Chat ID laukā vajadzīgs skaitlis, nevis uzaicinājuma saite.");
  if(code===400&&/rights|not enough|forbidden|write|send messages/.test(description))return new Error("Telegram botam nav atļauts sūtīt ziņas šajā grupā (400). Grupas atļaujās piešķir botam ziņu sūtīšanas tiesības.");
  return new Error(`Telegram serviss noraidīja pieprasījumu (${code}). Pārbaudi bota piekļuvi grupai un mēģini vēlreiz.`);
}
async function recordTelegramDestination(env:AppEnv,config:Integrations,destination:string,chat?:TelegramChat){
  const database=db(env),stored=await database.prepare("SELECT sealed FROM settings WHERE id='integrations'").first<{sealed:string}>();
  const saved:Partial<Integrations>=stored?await unseal(stored.sealed,env):{};
  // A slow send must never overwrite a group or token changed in another tab.
  if((saved.telegramToken||env.TELEGRAM_BOT_TOKEN||"")!==config.telegramToken||(saved.telegramChatId||env.TELEGRAM_CHAT_ID||"")!==config.telegramChatId)return;
  const next={...saved,telegramChatId:destination,telegramChatTitle:chat?.title||chat?.first_name||"",telegramChatType:chat?.type||"",telegramVerifiedAt:Date.now()};
  const encrypted=await seal(next,env);
  if(stored)await database.prepare("UPDATE settings SET sealed=?,updated_at=? WHERE id='integrations' AND sealed=?").bind(encrypted,Date.now(),stored.sealed).run();
  else await database.prepare("INSERT INTO settings(id,sealed,updated_at) VALUES ('integrations',?,?) ON CONFLICT(id) DO NOTHING").bind(encrypted,Date.now()).run();
}
export async function notify(text: string,config: Integrations,env?:AppEnv) {
  const signal=AbortSignal.timeout(7000);let destination=config.telegramChatId;
  for(let attempt=0;attempt<2;attempt++){
    const response=await serviceFetch(`https://api.telegram.org/bot${config.telegramToken}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({chat_id:destination,text:text.slice(0,3900),link_preview_options:{is_disabled:true}}),signal},"Telegram");
    const data=await response.json().catch(()=>({})) as TelegramResponse<{message_id?:number;chat?:TelegramChat}>;
    if(response.ok&&data.ok){
      // Only retry explicit migration failures, never an accepted message.
      if(env)try{await recordTelegramDestination(env,config,destination,data.result?.chat);}catch{console.error("Telegram destination metadata was not saved; message accepted.");}
      return String(data.result?.message_id||"accepted");
    }
    const migrated=data.parameters?.migrate_to_chat_id;
    if(attempt===0&&Number.isSafeInteger(migrated)&&Number(migrated)<0&&String(migrated)!==destination){destination=String(migrated);continue;}
    throw telegramError(response.status,data);
  }
  throw new Error("Telegram grupas ID atjaunošana neizdevās. Atrodi grupu vēlreiz.");
}
export async function sendEmail(text:string,subject:string,config:Integrations,deliveryId:string,options:{to?:string;replyTo?:string;html?:string}={}){
  const payload=JSON.stringify({from:config.emailFrom,to:[options.to||config.emailTo],subject:subject.replace(/[\r\n]/g," ").slice(0,200),text,...(options.replyTo?{reply_to:options.replyTo}:{}),...(options.html?{html:options.html}:{})});
  const response=await serviceFetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${config.resendKey}`,"Content-Type":"application/json","Idempotency-Key":`lead-inbox/${deliveryId}/${(await hash(payload)).slice(0,32)}`},body:payload,signal:AbortSignal.timeout(7000)},"E-pasta");
  if(!response.ok)throw new Error(`E-pasta serviss atbildēja ar ${response.status}. Pārbaudi atslēgu, sūtītāja domēnu un saņēmēju.`);
  const data=await response.json() as {id?:string};
  if(!data.id)throw new Error("E-pasta serviss neapstiprināja ziņas pieņemšanu.");
  return data.id;
}
export function customerReceipt(lead:Pick<Lead,"id">){
  const receipt=lead.id.slice(0,8).toUpperCase();
  const text=`Labdien!\n\nPaldies! Tavs pieteikums ir saņemts un saglabāts.\nPieteikuma numurs: ${receipt}\n\nMūsu komanda izskatīs pieteikumu un sazināsies, izmantojot norādīto kontaktinformāciju.\n\nJa šo pieteikumu neiesniedzi tu, vari šo ziņu ignorēt.\n\nLead Inbox · Pieteikuma apstiprinājums`;
  const html=`<!doctype html><html lang="lv"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="margin:0;background:#f3f7f2;font-family:Arial,sans-serif;color:#173d32"><table role="presentation" style="width:100%;padding:24px 12px"><tr><td align="center"><table role="presentation" style="width:100%;max-width:560px;background:#fff;border-radius:16px;overflow:hidden"><tr><td style="background:#173d32;color:#c8ef97;padding:26px;font-size:25px;font-weight:bold">leadinbox.</td></tr><tr><td style="padding:30px 26px"><h1 style="font-size:26px;margin:0 0 20px">Pieteikums saņemts.</h1><p style="font-size:16px;line-height:1.7">Paldies! Tavs pieteikums ir saglabāts un pieejams mūsu komandai.</p><p style="padding:18px;background:#eff6e7;border-radius:8px;font-size:16px">Pieteikuma numurs: <strong>${receipt}</strong></p><p style="font-size:16px;line-height:1.7">Izskatīsim tavu pieteikumu un sazināsimies, izmantojot norādīto kontaktinformāciju.</p><p style="font-size:13px;line-height:1.6;color:#667b6e;margin-top:30px">Ja šo pieteikumu neiesniedzi tu, vari šo ziņu ignorēt.</p></td></tr></table></td></tr></table></body></html>`;
  return {text,html,subject:`Pieteikums saņemts · ${receipt}`};
}
async function sendCustomerConfirmation(lead:Lead,env:AppEnv,config:Integrations){
  if(lead.customer_email_state==="sent"||lead.customer_email_state==="disabled")return;
  const database=db(env),availability=confirmationAvailability(config,lead.email);
  if(availability==="disabled"){await database.prepare("UPDATE leads SET customer_email_state='disabled',customer_email_error=NULL WHERE id=?").bind(lead.id).run();return;}
  if(availability==="unavailable"){
    const reason=isTestSender(config)?"Resend testa sūtītājs nevar sūtīt klientiem. Apstiprini savu sūtītāja domēnu Resend un nomaini sūtītāju.":"Klienta apstiprinājumam vēl nav iestatīta Resend atslēga un sūtītājs.";
    await database.prepare("UPDATE leads SET customer_email_state='blocked',customer_email_error=? WHERE id=?").bind(reason,lead.id).run();return;
  }
  // Limit confirmation abuse across client IPs, without rejecting the saved lead.
  const now=Date.now(),windowMs=60*60000,key=`customer-email:${await hash(`${secret(env)}:${lead.email}`)}:${Math.floor(now/windowMs)}`;
  const quota=await database.prepare("INSERT INTO rate_limits (key,hits,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET hits=hits+1 RETURNING hits").bind(key,now+windowMs).first<{hits:number}>();
  if((quota?.hits||0)>3){await database.prepare("UPDATE leads SET customer_email_state='blocked',customer_email_error='Šai adresei sasniegts 3 apstiprinājumu mēģinājumu limits stundā. Pieteikums ir saglabāts.' WHERE id=?").bind(lead.id).run();return;}
  try{
    const receipt=customerReceipt(lead),messageId=await sendEmail(receipt.text,receipt.subject,config,`confirmation/${lead.id}`,{to:lead.email,replyTo:config.emailTo||undefined,html:receipt.html});
    await database.prepare("UPDATE leads SET customer_email_state='sent',customer_email_error=NULL,customer_email_sent_at=?,customer_email_message_id=?,updated_at=? WHERE id=?").bind(Date.now(),messageId,Date.now(),lead.id).run();
  }catch(error){await database.prepare("UPDATE leads SET customer_email_state='failed',customer_email_error=? WHERE id=?").bind(errorMessage(error),lead.id).run();}
}
function errorMessage(error: unknown) {
  if(error instanceof Error&&(error.name==="TimeoutError"||error.name==="AbortError")) return "Serviss neatbildēja laikā. Mēģini atkārtoti.";
  if(error instanceof Error&&/^(AI |Paziņojumu |Telegram |E-pasta )/.test(error.message)) return error.message;
  return "Apstrāde neizdevās. Pārbaudi iestatījumus un mēģini atkārtoti.";
}
export async function processLead(id: string,env: AppEnv,origin: string) {
  const database=db(env),now=Date.now();
  const lead=await database.prepare("UPDATE leads SET lease_until=?,attempts=attempts+1 WHERE id=? AND lease_until<? RETURNING *").bind(now+55000,id,now).first<Lead>();
  if(!lead) return;
  try {
    const config=await getIntegrations(env),ready=readiness(config);
    await Promise.all([sendCustomerConfirmation(lead,env,config),(async()=>{
    if(lead.ai_state!=="done") {
      if(!ready.ai) await database.prepare("UPDATE leads SET ai_state='blocked',ai_error=? WHERE id=?").bind(`AI ${config.aiProvider==="groq"?"Groq":"OpenAI"} atslēga vēl nav pievienota.`,id).run();
      else try {
        const assessment=await evaluate(lead,config);
        await database.prepare("UPDATE leads SET ai_rating=?,ai_reason=?,ai_opener=?,ai_state='done',ai_error=NULL,ai_model=?,ai_completed_at=?,updated_at=? WHERE id=?").bind(assessment.rating,assessment.reason,assessment.opener,recordedAiModel(config),Date.now(),Date.now(),id).run();
        lead.ai_rating=assessment.rating; lead.ai_reason=assessment.reason; lead.ai_opener=assessment.opener;
      } catch(error) { await database.prepare("UPDATE leads SET ai_state='failed',ai_error=? WHERE id=?").bind(errorMessage(error),id).run(); }
    }
    const message=`JAUNS LĪDS · ${lead.ai_rating||"AI vērtējums vēl nav pieejams"}\n\n${lead.name} · ${lead.company}\n${lead.phone}\n${lead.email}\n${lead.industry} · ${lead.revenue}/mēn.\n\nMērķis: ${lead.goal.slice(0,500)}\n\n${lead.ai_reason||"Atver inbox un pārbaudi AI apstrādes statusu."}${lead.ai_opener?`\n\nSarunas sākums: ${lead.ai_opener}`:""}\n\nInbox: ${origin}/inbox?lead=${id}\nID: ${id.slice(0,8)}`;
    await Promise.all([
      (async()=>{
        if(lead.notification_state==="sent")return;
        if(!config.messengerEnabled){await database.prepare("UPDATE leads SET notification_state='disabled',notification_error=NULL WHERE id=?").bind(id).run();return;}
        if(!ready.messengerReady){await database.prepare("UPDATE leads SET notification_state='blocked',notification_error='Telegram vēl nav pieslēgts.' WHERE id=?").bind(id).run();return;}
        try{const messageId=await notify(message,config,env);await database.prepare("UPDATE leads SET notification_state='sent',notification_channel=?,notification_error=NULL,notification_sent_at=?,notification_message_id=?,updated_at=? WHERE id=?").bind(config.notificationProvider,Date.now(),messageId,Date.now(),id).run();}
        catch(error){await database.prepare("UPDATE leads SET notification_state='failed',notification_error=? WHERE id=?").bind(errorMessage(error),id).run();}
      })(),
      (async()=>{
        // Migration marks historical email deliveries disabled. Only a new lead or explicit retry enables them.
        if(lead.email_state==="sent"||lead.email_state==="disabled")return;
        if(!config.emailEnabled){await database.prepare("UPDATE leads SET email_state='disabled',email_error=NULL WHERE id=?").bind(id).run();return;}
        if(!ready.emailReady){await database.prepare("UPDATE leads SET email_state='blocked',email_error='E-pasta atslēga, sūtītājs vai saņēmējs vēl nav iestatīts.' WHERE id=?").bind(id).run();return;}
        try{const messageId=await sendEmail(message,`Jauns līds: ${lead.company} · ${lead.ai_rating||"Jauns"}`,config,id);await database.prepare("UPDATE leads SET email_state='sent',email_error=NULL,email_sent_at=?,email_message_id=?,updated_at=? WHERE id=?").bind(Date.now(),messageId,Date.now(),id).run();}
        catch(error){await database.prepare("UPDATE leads SET email_state='failed',email_error=? WHERE id=?").bind(errorMessage(error),id).run();}
      })(),
    ]);
    })()]);
  } finally { await database.prepare("UPDATE leads SET lease_until=0,updated_at=? WHERE id=?").bind(Date.now(),id).run(); }
}
async function resumePending(env: AppEnv,origin: string) {
  const database=db(env);
  const rows=await database.prepare("SELECT id FROM leads WHERE (ai_state='pending' OR notification_state='pending' OR email_state='pending' OR customer_email_state='pending') AND lease_until<? AND attempts<4 ORDER BY created_at LIMIT 3").bind(Date.now()).all<{id:string}>();
  await Promise.allSettled(rows.results.map(v=>processLead(v.id,env,origin)));
  await database.batch([database.prepare("DELETE FROM sessions WHERE expires_at<?").bind(Date.now()),database.prepare("DELETE FROM rate_limits WHERE expires_at<?").bind(Date.now())]);
}
function background(ctx: Pick<ExecutionContext,"waitUntil">,promise: Promise<unknown>) {
  ctx.waitUntil(promise.catch(()=>{console.error("Lead Inbox background processing failed; durable lead retained.");}));
}

export async function handleApi(incomingRequest: Request,env: AppEnv,ctx: Pick<ExecutionContext,"waitUntil">): Promise<Response> {
  const request=await restoreProxyRequest(incomingRequest,env.LEAD_PROXY_SECRET);
  if(!request)return json({error:"Šis servera savienojums nav atļauts."},403);
  const url=new URL(request.url),path=url.pathname,method=request.method;
  try {
    const database=db(env);
    if(!["GET","HEAD","OPTIONS"].includes(method)) checkOrigin(request);
    if(path==="/api/status"&&method==="GET") {
      const config=await getIntegrations(env);
      const latest=await database.prepare("SELECT MAX(CASE WHEN ai_state='done' AND ai_model=? THEN ai_completed_at END) AS ai_at, MAX(CASE WHEN notification_state='sent' AND notification_channel='telegram' THEN notification_sent_at END) AS telegram_at, MAX(CASE WHEN email_state='sent' THEN email_sent_at END) AS email_at, MAX(CASE WHEN customer_email_state='sent' THEN customer_email_sent_at END) AS customer_email_at FROM leads").bind(recordedAiModel(config)).first<{ai_at:number|null;telegram_at:number|null;email_at:number|null;customer_email_at:number|null}>();
      const ready=readiness(config);
      const channels=[...(config.messengerEnabled?[{id:config.notificationProvider,configured:ready.messengerReady,lastSuccessAt:latest?.telegram_at??null}]:[]),...(config.emailEnabled?[{id:"email",configured:ready.emailReady,lastSuccessAt:latest?.email_at??null}]:[])];
      return json({checkedAt:Date.now(),database:"available",pinConfigured:Boolean(env.PIN_HASH&&env.SESSION_SECRET),ai:{configured:ready.ai,provider:config.aiProvider,model:selectedAiModel(config),lastSuccessAt:latest?.ai_at??null},notifications:{configured:ready.notifications,provider:config.notificationProvider,lastSuccessAt:Math.max(0,...channels.map(v=>v.lastSuccessAt||0))||null,channels},customerConfirmation:{enabled:config.customerEmailEnabled,configured:ready.customerEmailReady,testSender:ready.emailTestSender,lastSuccessAt:latest?.customer_email_at??null}});
    }
    if(path==="/api/session"&&method==="POST") {
      secret(env); await rateLimit(request,env,"pin",8,15*60000);
      const data=await body(request);
      if(!/^\d{6}$/.test(data.pin||"")||await hash(`${secret(env)}:${data.pin}`)!==env.PIN_HASH) throw new HttpError(401,"Nepareizs PIN kods.");
      const token=randomToken();
      await database.prepare("INSERT INTO sessions(token_hash,expires_at) VALUES (?,?)").bind(await hash(token),Date.now()+sessionAge*1000).run();
      return json({ok:true},200,{"Set-Cookie":`${cookieName}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${sessionAge}`});
    }
    if(path==="/api/session"&&method==="GET") return json({authenticated:await session(request,env)});
    if(path==="/api/session"&&method==="DELETE") {
      await authorize(request,env);
      const token=request.headers.get("cookie")?.match(/(?:^|;\s*)lead_session=([a-f0-9]{64})(?:;|$)/)?.[1];
      if(token) await database.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await hash(token)).run();
      return json({ok:true},200,{"Set-Cookie":`${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`});
    }
    if(path==="/api/leads"&&method==="POST") {
      secret(env);
      const parsed=leadInput.safeParse(await body(request));
      if(!parsed.success) throw new HttpError(422,"Pārbaudi atzīmētos laukus.",{fields:parsed.error.flatten().fieldErrors});
      const value=parsed.data;
      if(value.website) throw new HttpError(422,"Pieteikumu nevarēja nosūtīt.");
      const existing=await database.prepare("SELECT id,customer_email_state FROM leads WHERE submission_id=?").bind(value.submissionId).first<{id:string;customer_email_state:string}>();
      if(existing) return json({ok:true,id:existing.id,duplicate:true,confirmation:existing.customer_email_state==="sent"?"sent":existing.customer_email_state==="pending"?"pending":existing.customer_email_state==="disabled"?"disabled":"unavailable"});
      await rateLimit(request,env,"submit-minute",8,60000); await rateLimit(request,env,"submit-hour",60,60*60000);
      const id=crypto.randomUUID(),now=Date.now();
      const config=await getIntegrations(env);
      const inserted=await database.prepare("INSERT INTO leads(id,submission_id,name,phone,email,company,industry,revenue,goal,created_at,updated_at,consent_at,email_state,customer_email_state) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'pending',?) ON CONFLICT(submission_id) DO NOTHING RETURNING id").bind(id,value.submissionId,value.name,value.phone,value.email,value.company,value.industry,value.revenue,value.goal,now,now,value.consent?now:0,config.customerEmailEnabled?"pending":"disabled").first<{id:string}>();
      const actualId=inserted?.id||(await database.prepare("SELECT id FROM leads WHERE submission_id=?").bind(value.submissionId).first<{id:string}>())?.id;
      if(!actualId) throw new HttpError(500,"Neizdevās saglabāt pieteikumu.");
      if(inserted) background(ctx,processLead(id,env,url.origin));
      return json({ok:true,id:actualId,confirmation:confirmationAvailability(config,value.email)},201);
    }
    await authorize(request,env);
    if(path==="/api/leads"&&method==="GET") {
      const result=await database.prepare("SELECT * FROM leads ORDER BY created_at DESC,id DESC LIMIT 1000").all<Lead>();
      background(ctx,resumePending(env,url.origin));
      return json({leads:result.results,integrations:readiness(await getIntegrations(env)),limit:1000,serverTime:Date.now()});
    }
    const match=path.match(/^\/api\/leads\/([a-f0-9-]{36})(\/retry)?$/);
    if(match&&method==="PATCH"&&!match[2]) {
      const data=z.object({status:z.enum(STATUSES).optional(),notes:z.string().trim().max(3000).optional()}).refine(v=>v.status!==undefined||v.notes!==undefined).parse(await body(request));
      const updated=await database.prepare("UPDATE leads SET status=COALESCE(?,status),notes=COALESCE(?,notes),updated_at=? WHERE id=? RETURNING *").bind(data.status??null,data.notes??null,Date.now(),match[1]).first<Lead>();
      if(!updated) throw new HttpError(404,"Līds nav atrasts.");
      return json({lead:updated});
    }
    if(match&&method==="POST"&&match[2]) {
      const changed=await database.prepare("UPDATE leads SET ai_state=CASE WHEN ai_state='done' THEN ai_state ELSE 'pending' END,notification_state=CASE WHEN notification_state='sent' THEN notification_state ELSE 'pending' END,email_state=CASE WHEN email_state='sent' THEN email_state ELSE 'pending' END,customer_email_state=CASE WHEN customer_email_state IN ('sent','disabled') THEN customer_email_state ELSE 'pending' END WHERE id=? AND lease_until<? RETURNING id").bind(match[1],Date.now()).first();
      if(!changed) throw new HttpError(409,"Apstrāde jau notiek vai līds nav atrasts.");
      background(ctx,processLead(match[1],env,url.origin)); return json({ok:true});
    }
    if(path==="/api/settings"&&method==="GET") {
      const config=await getIntegrations(env);
      return json({...readiness(config),openaiModel:config.aiModel,groqModel:config.groqModel,hasGroqKey:Boolean(config.groqKey),telegramChatId:config.telegramChatId,telegramChatTitle:config.telegramChatTitle,telegramChatType:config.telegramChatType,telegramVerifiedAt:config.telegramVerifiedAt,hasTelegramToken:Boolean(config.telegramToken),hasAiKey:Boolean(config.aiKey),hasResendKey:Boolean(config.resendKey),emailFrom:config.emailFrom,emailTo:config.emailTo});
    }
    if(path==="/api/settings"&&method==="POST") {
      await rateLimit(request,env,"settings",20,60000);
      const parsed=z.object({aiProvider:z.enum(["openai","groq"]).optional(),aiKey:z.string().trim().max(512).optional(),groqKey:z.string().trim().max(512).optional(),aiModel:z.string().trim().min(1).max(80).regex(/^[a-zA-Z0-9._:/-]+$/).optional(),notificationProvider:z.literal("telegram").optional(),telegramToken:z.string().trim().max(250).optional(),telegramChatId:z.string().trim().max(100).optional(),messengerEnabled:z.boolean().optional(),emailEnabled:z.boolean().optional(),customerEmailEnabled:z.boolean().optional(),resendKey:z.string().trim().max(512).optional(),emailFrom:z.union([z.string().trim().max(254).email(),z.literal("")]).optional(),emailTo:z.union([z.string().trim().max(254).email(),z.literal("")]).optional()}).refine(value=>Object.keys(value).length>0).parse(await body(request));
      if(parsed.aiKey&&!/^sk-[A-Za-z0-9_-]+$/.test(parsed.aiKey)) throw new HttpError(422,"Pārbaudi OpenAI API atslēgu.");
      if(parsed.groqKey&&!/^gsk_[A-Za-z0-9_-]+$/.test(parsed.groqKey))throw new HttpError(422,"Pārbaudi Groq API atslēgu. Tai jāsākas ar gsk_.");
      if(parsed.telegramToken&&!/^\d+:[A-Za-z0-9_-]+$/.test(parsed.telegramToken)) throw new HttpError(422,"Pārbaudi Telegram bota atslēgu.");
      if(parsed.telegramChatId&&!/^(?:-?\d+|@[A-Za-z0-9_]{5,})$/.test(parsed.telegramChatId)) throw new HttpError(422,"Pārbaudi Telegram Chat ID.");
      if(parsed.resendKey&&!/^re_[A-Za-z0-9_-]+$/.test(parsed.resendKey)) throw new HttpError(422,"Pārbaudi Resend API atslēgu.");
      const config=await getIntegrations(env);
      const aiProvider=parsed.aiProvider??config.aiProvider;
      const changedDestination=(parsed.telegramToken&&parsed.telegramToken!==config.telegramToken)||(parsed.telegramChatId!==undefined&&parsed.telegramChatId!==config.telegramChatId);
      const updated: Integrations={...config,aiProvider,aiModel:aiProvider==="openai"?(parsed.aiModel??config.aiModel):config.aiModel,groqModel:aiProvider==="groq"?(parsed.aiModel??config.groqModel):config.groqModel,groqKey:parsed.groqKey||config.groqKey,notificationProvider:"telegram",telegramChatId:parsed.telegramChatId??config.telegramChatId,aiKey:parsed.aiKey||config.aiKey,telegramToken:parsed.telegramToken||config.telegramToken,messengerEnabled:parsed.messengerEnabled??config.messengerEnabled,emailEnabled:parsed.emailEnabled??config.emailEnabled,customerEmailEnabled:parsed.customerEmailEnabled??config.customerEmailEnabled,resendKey:parsed.resendKey||config.resendKey,emailFrom:parsed.emailFrom??config.emailFrom,emailTo:parsed.emailTo??config.emailTo,...(changedDestination?{telegramChatTitle:"",telegramChatType:"",telegramVerifiedAt:0}:{})};
      await database.prepare("INSERT INTO settings(id,sealed,updated_at) VALUES ('integrations',?,?) ON CONFLICT(id) DO UPDATE SET sealed=excluded.sealed,updated_at=excluded.updated_at").bind(await seal(updated,env),Date.now()).run();
      return json({ok:true,...readiness(updated)});
    }
    if(path==="/api/settings/telegram-chats"&&method==="POST") {
      await rateLimit(request,env,"telegram-chats",6,60000);
      const {groupsOnly}=z.object({groupsOnly:z.boolean().optional()}).parse(await body(request));
      const config=await getIntegrations(env);
      if(!config.telegramToken) throw new HttpError(422,"Ievadi Telegram bota atslēgu, tad atrodi grupu.");
      const response=await serviceFetch(`https://api.telegram.org/bot${config.telegramToken}/getUpdates?limit=100`,{signal:AbortSignal.timeout(7000)},"Telegram");
      type ChatMessage={chat?:TelegramChat;migrate_to_chat_id?:number;migrate_from_chat_id?:number};
      const data=await response.json().catch(()=>({})) as TelegramResponse<{message?:ChatMessage;channel_post?:ChatMessage;my_chat_member?:{chat?:TelegramChat;new_chat_member?:{status?:string}}}[]>;
      if(!response.ok||!data.ok)throw telegramError(response.status,data,true);
      const chats=new Map<string,{id:string;name:string;type:string}>(),migrations=new Map<string,string>(),removed=new Set<string>();
      for(const update of data.result||[]){
        const message=update.message||update.channel_post,chat=message?.chat||update.my_chat_member?.chat;
        if(!chat)continue;
        const id=String(chat.id),type=chat.type||(chat.id<0?"group":"private");
        chats.set(id,{id,name:chat.title||chat.first_name||id,type});
        if(message?.migrate_to_chat_id&&Number.isSafeInteger(message.migrate_to_chat_id))migrations.set(id,String(message.migrate_to_chat_id));
        if(message?.migrate_from_chat_id&&Number.isSafeInteger(message.migrate_from_chat_id))migrations.set(String(message.migrate_from_chat_id),id);
        if(update.my_chat_member?.new_chat_member?.status&&["left","kicked"].includes(update.my_chat_member.new_chat_member.status))removed.add(id);else removed.delete(id);
      }
      for(const [oldId,newId]of migrations){const old=chats.get(oldId);if(old&&!chats.has(newId))chats.set(newId,{...old,id:newId,type:"supergroup"});chats.delete(oldId);}
      for(const id of removed)chats.delete(id);
      return json({chats:[...chats.values()].filter(chat=>!groupsOnly||["group","supergroup","channel"].includes(chat.type)),selectedChatId:migrations.get(config.telegramChatId)||config.telegramChatId});
    }
    if(path==="/api/settings/test"&&method==="POST") {
      await rateLimit(request,env,"integration-test",6,60000);
      const {target}=z.object({target:z.enum(["ai","notifications","email"])}).parse(await body(request));
      const config=await getIntegrations(env),ready=readiness(config);
      if(target==="ai") {
        if(!ready.ai) throw new HttpError(422,"Ievadi izvēlētā AI pakalpojuma API atslēgu.");
        const result=await evaluate({company:"Pārbaudes uzņēmums",industry:"Pakalpojumi",revenue:"10 000–50 000 €",goal:"Vēlamies 30 dienu laikā ieviest automātisku pieteikumu apstrādi. Ir 1500 eiro budžets, gribam sākt šonedēļ."},config);
        return json({ok:true,message:`AI strādā. Testa vērtējums: ${result.rating}. ${result.reason}`});
      }
      if(target==="email"){
        if(!ready.emailReady)throw new HttpError(422,"Testa e-pastam ievadi Resend atslēgu, sūtītāju un saņēmēju.");
        await sendEmail(`LEAD INBOX · Savienojuma pārbaude\n\nJauno līdu paziņojumi tiks sūtīti uz šo adresi.\n${url.origin}/inbox`,"Lead Inbox · testa paziņojums",config,`test-${crypto.randomUUID()}`);
        return json({ok:true,message:"Resend pieņēma testa e-pastu. Pārbaudi saņēmēja iesūtni un mēstuļu mapi."});
      }
      if(!ready.messengerReady) throw new HttpError(422,"Ievadi bota atslēgu un izvēlies grupu, nospiežot “Atrast grupu”.");
      await notify(`LEAD INBOX · Savienojuma pārbaude\n\nPaziņojumi ir pieslēgti. Jaunie līdi tiks sūtīti šeit.\n${url.origin}/inbox`,config,env);
      const destination=await getIntegrations(env);
      return json({ok:true,message:`Telegram pieņēma testa paziņojumu${destination.telegramChatTitle?` čatā “${destination.telegramChatTitle}”`:""}. Atver grupu un pārbaudi ziņu.`});
    }
    throw new HttpError(404,"Nav atrasts.");
  } catch(error) {
    if(error instanceof HttpError) return json({error:error.message,...error.extra},error.status,error.status===429?{"Retry-After":String(error.extra.retryAfterSeconds||60)}:{});
    if(error instanceof z.ZodError) return json({error:"Pārbaudi ievadītos datus.",fields:error.flatten().fieldErrors},422);
    console.error("Lead Inbox API error",path,error instanceof Error?error.name:"unknown");
    return json({error:errorMessage(error)},500);
  }
}

import { z } from "zod";
import { leadInput, aiOutput, AI_SCHEMA, AI_INSTRUCTIONS, STATUSES, type Lead } from "./leads-domain.ts";

export type AppEnv = {
  DB?: D1Database; PIN_HASH?: string; SESSION_SECRET?: string;
  OPENAI_API_KEY?: string; OPENAI_MODEL?: string;
  AI_PROVIDER?: string; GROQ_API_KEY?: string; GROQ_MODEL?: string;
  TELEGRAM_BOT_TOKEN?: string; TELEGRAM_CHAT_ID?: string; DISCORD_WEBHOOK_URL?: string;
  RESEND_API_KEY?: string; EMAIL_FROM?: string; EMAIL_TO?: string;
};
type Integrations = {
  aiKey: string; aiModel: string; notificationProvider: "telegram" | "discord";
  aiProvider: "openai" | "groq"; groqKey: string; groqModel: string;
  telegramToken: string; telegramChatId: string; discordWebhook: string;
  messengerEnabled: boolean; emailEnabled: boolean; resendKey: string; emailFrom: string; emailTo: string;
};
class HttpError extends Error {
  status: number; extra: Record<string, unknown>;
  constructor(status: number, message: string, extra: Record<string, unknown> = {}) { super(message); this.status=status; this.extra=extra; }
}
const encoder = new TextEncoder(), cookieName = "lead_session", sessionAge = 12*60*60;
export async function hash(value: string) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",encoder.encode(value))),b=>b.toString(16).padStart(2,"0")).join("");
}
function randomToken() { return Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,"0")).join(""); }
function db(env: AppEnv) { if(!env.DB) throw new HttpError(503,"Datubāze īslaicīgi nav pieejama."); return env.DB; }
function secret(env: AppEnv) { if(!env.SESSION_SECRET||!env.PIN_HASH) throw new HttpError(503,"Piekļuve vēl nav konfigurēta."); return env.SESSION_SECRET; }
export function json(data: unknown, status=200, headers: Record<string,string>={}) {
  return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff",...headers}});
}
async function body(request: Request) {
  if(!request.headers.get("content-type")?.includes("application/json")) throw new HttpError(415,"Nepieciešami JSON dati.");
  if(Number(request.headers.get("content-length")||0)>16000) throw new HttpError(413,"Pieteikums ir pārāk liels.");
  const text=await request.text();
  if(encoder.encode(text).length>16000) throw new HttpError(413,"Pieteikums ir pārāk liels.");
  try { return JSON.parse(text); } catch { throw new HttpError(400,"Neizdevās nolasīt pieteikumu."); }
}
function checkOrigin(request: Request) {
  const origin=request.headers.get("origin");
  if((origin&&origin!==new URL(request.url).origin)||request.headers.get("sec-fetch-site")==="cross-site") throw new HttpError(403,"Šis pieprasījums nav atļauts.");
}
async function rateLimit(request: Request, env: AppEnv, scope: string, limit: number, windowMs: number) {
  const now=Date.now(),ip=request.headers.get("cf-connecting-ip")||"local";
  const key=`${scope}:${await hash(`${env.SESSION_SECRET}:${ip}`)}:${Math.floor(now/windowMs)}`;
  const result=await db(env).prepare("INSERT INTO rate_limits (key,hits,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET hits=hits+1 RETURNING hits").bind(key,now+windowMs).first<{hits:number}>();
  if((result?.hits||0)>limit) {
    const retryAfterSeconds=Math.max(1,Math.ceil(((Math.floor(now/windowMs)+1)*windowMs-now)/1000));
    throw new HttpError(429,"Pārāk daudz mēģinājumu. Lūdzu, pamēģini vēlāk.",{retryAfterSeconds});
  }
}
async function session(request: Request,env: AppEnv) {
  const token=request.headers.get("cookie")?.match(/(?:^|;\s*)lead_session=([a-f0-9]{64})(?:;|$)/)?.[1];
  if(!token) return false;
  return Boolean(await db(env).prepare("SELECT token_hash FROM sessions WHERE token_hash=? AND expires_at>?").bind(await hash(token),Date.now()).first());
}
async function authorize(request: Request,env: AppEnv) { if(!await session(request,env)) throw new HttpError(401,"Ievadi PIN, lai atvērtu inbox."); }
async function encryptionKey(env: AppEnv) {
  return crypto.subtle.importKey("raw",await crypto.subtle.digest("SHA-256",encoder.encode(secret(env))),"AES-GCM",false,["encrypt","decrypt"]);
}
export async function seal(value: unknown,env: AppEnv) {
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ciphertext=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv},await encryptionKey(env),encoder.encode(JSON.stringify(value))));
  const bytes=new Uint8Array(iv.length+ciphertext.length); bytes.set(iv); bytes.set(ciphertext,iv.length);
  return btoa(String.fromCharCode(...bytes));
}
export async function unseal(value: string,env: AppEnv) {
  const bytes=Uint8Array.from(atob(value),v=>v.charCodeAt(0));
  return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:"AES-GCM",iv:bytes.slice(0,12)},await encryptionKey(env),bytes.slice(12))));
}
export async function getIntegrations(env: AppEnv): Promise<Integrations> {
  const stored=await db(env).prepare("SELECT sealed FROM settings WHERE id='integrations'").first<{sealed:string}>();
  const saved=stored?await unseal(stored.sealed,env) as Partial<Integrations>:{};
  return {aiKey:saved.aiKey||env.OPENAI_API_KEY||"",aiModel:saved.aiModel||env.OPENAI_MODEL||"gpt-4.1-mini",
    aiProvider:saved.aiProvider||(env.AI_PROVIDER==="groq"||(!env.AI_PROVIDER&&env.GROQ_API_KEY)?"groq":"openai"),groqKey:saved.groqKey||env.GROQ_API_KEY||"",groqModel:saved.groqModel||env.GROQ_MODEL||"openai/gpt-oss-20b",
    notificationProvider:saved.notificationProvider||(env.DISCORD_WEBHOOK_URL?"discord":"telegram"),
    telegramToken:saved.telegramToken||env.TELEGRAM_BOT_TOKEN||"",telegramChatId:saved.telegramChatId||env.TELEGRAM_CHAT_ID||"",discordWebhook:saved.discordWebhook||env.DISCORD_WEBHOOK_URL||"",
    messengerEnabled:saved.messengerEnabled??true,emailEnabled:saved.emailEnabled??Boolean(env.RESEND_API_KEY&&env.EMAIL_FROM&&env.EMAIL_TO),
    resendKey:saved.resendKey||env.RESEND_API_KEY||"",emailFrom:saved.emailFrom??env.EMAIL_FROM??"",emailTo:saved.emailTo??env.EMAIL_TO??""};
}
function selectedAiModel(config:Integrations){return config.aiProvider==="groq"?config.groqModel:config.aiModel;}
function recordedAiModel(config:Integrations){return config.aiProvider==="groq"?`Groq · ${config.groqModel}`:config.aiModel;}
function readiness(config: Integrations) {
  const messengerReady=config.notificationProvider==="telegram"?Boolean(config.telegramToken&&config.telegramChatId):Boolean(config.discordWebhook);
  const emailReady=Boolean(config.resendKey&&config.emailFrom&&config.emailTo);
  return {ai:Boolean(config.aiProvider==="groq"?config.groqKey:config.aiKey),notifications:(config.messengerEnabled||config.emailEnabled)&&(!config.messengerEnabled||messengerReady)&&(!config.emailEnabled||emailReady),
    notificationProvider:config.notificationProvider,aiProvider:config.aiProvider,aiModel:selectedAiModel(config),messengerEnabled:config.messengerEnabled,emailEnabled:config.emailEnabled,messengerReady,emailReady};
}
async function serviceFetch(url:string,options:RequestInit,label:string){
  try{
    // Workers supports manual/follow, but not the Fetch standard's error mode.
    // Return redirects as unsuccessful responses without forwarding credentials.
    return await fetch(url,{...options,redirect:"manual"});
  }catch(error){
    if(error instanceof Error&&(error.name==="AbortError"||error.name==="TimeoutError"))throw error;
    throw new Error(`${label} savienojumu ar servisu neizdevās izveidot. Jāpārbauda servera savienojums un jāmēģina vēlreiz.`);
  }
}
export async function evaluate(lead: Pick<Lead,"company"|"industry"|"revenue"|"goal">,config: Integrations) {
  if(config.aiProvider==="groq")return evaluateGroq(lead,config);
  const response=await serviceFetch("https://api.openai.com/v1/responses",{method:"POST",headers:{Authorization:`Bearer ${config.aiKey}`,"Content-Type":"application/json"},
    body:JSON.stringify({model:config.aiModel,store:false,instructions:AI_INSTRUCTIONS,input:JSON.stringify({company:lead.company,industry:lead.industry,monthlyRevenue:lead.revenue,goal:lead.goal}),text:{format:{type:"json_schema",name:"lead_assessment",strict:true,schema:AI_SCHEMA}},max_output_tokens:600}),
    signal:AbortSignal.timeout(17000)},"AI");
  if(!response.ok){
    const raw=await response.text();
    let data:{error?:{code?:string;type?:string;message?:string}}|null=null;
    try{data=JSON.parse(raw);}catch{/* A gateway may return HTML instead of an OpenAI API error. */}
    const code=data?.error?.code||data?.error?.type;
    const knownCode=["insufficient_quota","credit_balance_exhausted","organization_spend_limit_exceeded","project_spend_limit_exceeded","organization_usage_limit_exceeded","slow_down","rate_limit_exceeded","invalid_api_key","model_not_found","billing_hard_limit_reached","billing_not_active","quota_exceeded"].includes(code||"")?code:"unknown";
    const hint=(typeof data?.error?.message==="string"?data.error.message:raw).toLowerCase();
    const billingHint=/billing|payment method|credits|quota|balance/.test(hint),zeroLimit=/limit\s*:?\s*0\b/.test(hint);
    // Log only classified metadata, never provider messages, keys or headers.
    console.error("Lead Inbox AI provider response",JSON.stringify({status:response.status,code:knownCode,json:response.headers.get("content-type")?.includes("json")||false,structured:Boolean(data?.error),billingHint,zeroLimit,rateHint:/rate limit|too many requests/.test(hint),gatewayHint:/cloudflare|access denied|temporarily banned|error code:\s*1015/.test(hint)}));
    if(code==="credit_balance_exhausted")throw new Error("AI API kredīts ir beidzies (429, credit_balance_exhausted). Papildini kredītu OpenAI API Billing sadaļā.");
    if(code==="organization_spend_limit_exceeded"||code==="project_spend_limit_exceeded")throw new Error(`AI organizācijas vai projekta tēriņu limits ir sasniegts (429, ${code}). Pārbaudi OpenAI API Limits.`);
    if(code==="organization_usage_limit_exceeded")throw new Error("AI organizācijai piešķirtais API lietojuma limits ir sasniegts (429, organization_usage_limit_exceeded). Jāpieprasa lielāks limits OpenAI.");
    if(code==="slow_down")throw new Error("AI pieprasījumu ātrums pieaudzis pārāk strauji (429, slow_down). Uzgaidi un mēģini vēlreiz.");
    if(code==="insufficient_quota")throw new Error(`AI API kredīts nav pieejams vai sasniegts tēriņu limits (${response.status}, insufficient_quota). Pārbaudi OpenAI API Billing.`);
    if(response.status===401)throw new Error("AI atslēga nav derīga vai tai nav piekļuves (401). Pārbaudi OpenAI projekta atslēgu.");
    if(code==="model_not_found"||response.status===403)throw new Error(`AI modelim vai projektam nav piekļuves (${response.status}). Pārbaudi modeli un atslēgas tiesības.`);
    if(response.status===429&&code==="rate_limit_exceeded")throw new Error(billingHint||zeroLimit?"AI projekta pieprasījumu limits ir sasniegts vai ir 0 (429, rate_limit_exceeded). Pārbaudi OpenAI API Billing un Limits.":"AI pieprasījumu ātruma limits ir sasniegts (429, rate_limit_exceeded). Uzgaidi un mēģini vēlreiz.");
    if(response.status===429)throw new Error("AI serviss noraidīja pieprasījumu (429), bet nenorādīja atpazīstamu iemeslu. Jāpārbauda OpenAI API kvota un savienojuma ierobežojumi.");
    throw new Error(`AI serviss atbildēja ar ${response.status}. Pārbaudi atslēgu, modeli un API kredītu.`);
  }
  const data=await response.json() as {output?:{content?:{type:string;text?:string}[]}[]};
  const text=data.output?.flatMap(v=>v.content||[]).filter(v=>v.type==="output_text").map(v=>v.text||"").join("");
  if(!text) throw new Error("AI neatgrieza vērtējumu. Mēģini vēlreiz.");
  return aiOutput.parse(JSON.parse(text));
}
async function evaluateGroq(lead:Pick<Lead,"company"|"industry"|"revenue"|"goal">,config:Integrations){
  const response=await serviceFetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${config.groqKey}`,"Content-Type":"application/json"},body:JSON.stringify({
    model:config.groqModel,messages:[{role:"system",content:AI_INSTRUCTIONS},{role:"user",content:JSON.stringify({company:lead.company,industry:lead.industry,monthlyRevenue:lead.revenue,goal:lead.goal})}],
    response_format:{type:"json_schema",json_schema:{name:"lead_assessment",strict:true,schema:AI_SCHEMA}},max_completion_tokens:1200,temperature:0.2,...(config.groqModel.startsWith("openai/gpt-oss-")?{reasoning_effort:"low"}:{}),
  }),signal:AbortSignal.timeout(17000)},"AI Groq");
  if(!response.ok){
    if(response.status===401)throw new Error("AI Groq atslēga nav derīga (401). Pārbaudi saglabāto Groq API atslēgu.");
    if(response.status===429)throw new Error("AI Groq kvotas limits ir sasniegts (429). Sagaidi kvotas atjaunošanos un atkārto apstrādi; pieteikums paliek saglabāts.");
    if(response.status===403||response.status===404)throw new Error(`AI Groq modelim nav piekļuves (${response.status}). Pārbaudi izvēlēto modeli un konta tiesības.`);
    throw new Error(`AI Groq serviss atbildēja ar ${response.status}. Pārbaudi savienojumu un modeļa iestatījumus.`);
  }
  const data=await response.json() as {choices?:{message?:{content?:string|null};finish_reason?:string}[]};
  const choice=data.choices?.[0];
  if(!choice?.message?.content||choice.finish_reason==="length")throw new Error("AI Groq atbilde bija nepilnīga. Atkārto apstrādi.");
  let value:unknown;try{value=JSON.parse(choice.message.content);}catch{throw new Error("AI Groq neatgrieza derīgu vērtējumu. Atkārto apstrādi.");}
  const parsed=aiOutput.safeParse(value);if(!parsed.success)throw new Error("AI Groq vērtējums neatbilst prasītajai formai. Atkārto apstrādi.");
  return parsed.data;
}
export async function notify(text: string,config: Integrations) {
  const telegram=config.notificationProvider==="telegram";
  const response=await serviceFetch(telegram?`https://api.telegram.org/bot${config.telegramToken}/sendMessage`:`${config.discordWebhook}?wait=true`,{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify(telegram?{chat_id:config.telegramChatId,text:text.slice(0,3900),link_preview_options:{is_disabled:true}}:{content:text.slice(0,1950),allowed_mentions:{parse:[]}}),signal:AbortSignal.timeout(7000)},"Paziņojumu");
  if(!response.ok) throw new Error(`Paziņojumu serviss atbildēja ar ${response.status}. Pārbaudi piekļuvi un saņēmēju.`);
  const data=await response.json() as {ok?:boolean;result?:{message_id?:number};id?:string};
  if(telegram&&!data.ok) throw new Error("Telegram paziņojumu nepieņēma.");
  return String(telegram?data.result?.message_id||"accepted":data.id||"accepted");
}
export async function sendEmail(text:string,subject:string,config:Integrations,deliveryId:string){
  const payload=JSON.stringify({from:config.emailFrom,to:[config.emailTo],subject:subject.replace(/[\r\n]/g," ").slice(0,200),text});
  const response=await serviceFetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${config.resendKey}`,"Content-Type":"application/json","Idempotency-Key":`lead-inbox/${deliveryId}/${(await hash(payload)).slice(0,32)}`},body:payload,signal:AbortSignal.timeout(7000)},"E-pasta");
  if(!response.ok)throw new Error(`E-pasta serviss atbildēja ar ${response.status}. Pārbaudi atslēgu, sūtītāja domēnu un saņēmēju.`);
  const data=await response.json() as {id?:string};
  if(!data.id)throw new Error("E-pasta serviss neapstiprināja ziņas pieņemšanu.");
  return data.id;
}
function errorMessage(error: unknown) {
  if(error instanceof Error&&(error.name==="TimeoutError"||error.name==="AbortError")) return "Serviss neatbildēja laikā. Mēģini atkārtoti.";
  if(error instanceof Error&&/^(AI |Paziņojumu |Telegram |E-pasta )/.test(error.message)) return error.message;
  return "Apstrāde neizdevās. Pārbaudi iestatījumus un mēģini atkārtoti.";
}
export async function processLead(id: string,env: AppEnv,origin: string) {
  const database=db(env),now=Date.now();
  const lead=await database.prepare("UPDATE leads SET lease_until=?,attempts=attempts+1 WHERE id=? AND lease_until<? RETURNING *").bind(now+55000,id,now).first<Lead>();
  if(!lead) return;
  try {
    const config=await getIntegrations(env),ready=readiness(config);
    if(lead.ai_state!=="done") {
      if(!ready.ai) await database.prepare("UPDATE leads SET ai_state='blocked',ai_error=? WHERE id=?").bind(`AI ${config.aiProvider==="groq"?"Groq":"OpenAI"} atslēga vēl nav pievienota.`,id).run();
      else try {
        const assessment=await evaluate(lead,config);
        await database.prepare("UPDATE leads SET ai_rating=?,ai_reason=?,ai_opener=?,ai_state='done',ai_error=NULL,ai_model=?,ai_completed_at=?,updated_at=? WHERE id=?").bind(assessment.rating,assessment.reason,assessment.opener,recordedAiModel(config),Date.now(),Date.now(),id).run();
        lead.ai_rating=assessment.rating; lead.ai_reason=assessment.reason; lead.ai_opener=assessment.opener;
      } catch(error) { await database.prepare("UPDATE leads SET ai_state='failed',ai_error=? WHERE id=?").bind(errorMessage(error),id).run(); }
    }
    const message=`JAUNS LĪDS · ${lead.ai_rating||"AI vērtējums vēl nav pieejams"}\n\n${lead.name} · ${lead.company}\n${lead.phone}\n${lead.email}\n${lead.industry} · ${lead.revenue}/mēn.\n\nMērķis: ${lead.goal.slice(0,500)}\n\n${lead.ai_reason||"Atver inbox un pārbaudi AI apstrādes statusu."}${lead.ai_opener?`\n\nSarunas sākums: ${lead.ai_opener}`:""}\n\nInbox: ${origin}/inbox?lead=${id}\nID: ${id.slice(0,8)}`;
    await Promise.all([
      (async()=>{
        if(lead.notification_state==="sent")return;
        if(!config.messengerEnabled){await database.prepare("UPDATE leads SET notification_state='disabled',notification_error=NULL WHERE id=?").bind(id).run();return;}
        if(!ready.messengerReady){await database.prepare("UPDATE leads SET notification_state='blocked',notification_error='Telegram vai Discord vēl nav pieslēgts.' WHERE id=?").bind(id).run();return;}
        try{const messageId=await notify(message,config);await database.prepare("UPDATE leads SET notification_state='sent',notification_channel=?,notification_error=NULL,notification_sent_at=?,notification_message_id=?,updated_at=? WHERE id=?").bind(config.notificationProvider,Date.now(),messageId,Date.now(),id).run();}
        catch(error){await database.prepare("UPDATE leads SET notification_state='failed',notification_error=? WHERE id=?").bind(errorMessage(error),id).run();}
      })(),
      (async()=>{
        // Migration marks historical email deliveries disabled. Only a new lead or explicit retry enables them.
        if(lead.email_state==="sent"||lead.email_state==="disabled")return;
        if(!config.emailEnabled){await database.prepare("UPDATE leads SET email_state='disabled',email_error=NULL WHERE id=?").bind(id).run();return;}
        if(!ready.emailReady){await database.prepare("UPDATE leads SET email_state='blocked',email_error='E-pasta atslēga, sūtītājs vai saņēmējs vēl nav iestatīts.' WHERE id=?").bind(id).run();return;}
        try{const messageId=await sendEmail(message,`Jauns līds: ${lead.company} · ${lead.ai_rating||"Jauns"}`,config,id);await database.prepare("UPDATE leads SET email_state='sent',email_error=NULL,email_sent_at=?,email_message_id=?,updated_at=? WHERE id=?").bind(Date.now(),messageId,Date.now(),id).run();}
        catch(error){await database.prepare("UPDATE leads SET email_state='failed',email_error=? WHERE id=?").bind(errorMessage(error),id).run();}
      })(),
    ]);
  } finally { await database.prepare("UPDATE leads SET lease_until=0,updated_at=? WHERE id=?").bind(Date.now(),id).run(); }
}
async function resumePending(env: AppEnv,origin: string) {
  const database=db(env);
  const rows=await database.prepare("SELECT id FROM leads WHERE (ai_state='pending' OR notification_state='pending' OR email_state='pending') AND lease_until<? AND attempts<4 ORDER BY created_at LIMIT 3").bind(Date.now()).all<{id:string}>();
  await Promise.allSettled(rows.results.map(v=>processLead(v.id,env,origin)));
  await database.batch([database.prepare("DELETE FROM sessions WHERE expires_at<?").bind(Date.now()),database.prepare("DELETE FROM rate_limits WHERE expires_at<?").bind(Date.now())]);
}
function background(ctx: Pick<ExecutionContext,"waitUntil">,promise: Promise<unknown>) {
  ctx.waitUntil(promise.catch(()=>{console.error("Lead Inbox background processing failed; durable lead retained.");}));
}

export async function handleApi(request: Request,env: AppEnv,ctx: Pick<ExecutionContext,"waitUntil">): Promise<Response> {
  const url=new URL(request.url),path=url.pathname,method=request.method;
  try {
    const database=db(env);
    if(!["GET","HEAD","OPTIONS"].includes(method)) checkOrigin(request);
    if(path==="/api/status"&&method==="GET") {
      const config=await getIntegrations(env);
      const latest=await database.prepare("SELECT MAX(CASE WHEN ai_state='done' AND ai_model=? THEN ai_completed_at END) AS ai_at, MAX(CASE WHEN notification_state='sent' AND notification_channel='telegram' THEN notification_sent_at END) AS telegram_at, MAX(CASE WHEN notification_state='sent' AND notification_channel='discord' THEN notification_sent_at END) AS discord_at, MAX(CASE WHEN email_state='sent' THEN email_sent_at END) AS email_at FROM leads").bind(recordedAiModel(config)).first<{ai_at:number|null;telegram_at:number|null;discord_at:number|null;email_at:number|null}>();
      const ready=readiness(config);
      const channels=[...(config.messengerEnabled?[{id:config.notificationProvider,configured:ready.messengerReady,lastSuccessAt:(config.notificationProvider==="telegram"?latest?.telegram_at:latest?.discord_at)??null}]:[]),...(config.emailEnabled?[{id:"email",configured:ready.emailReady,lastSuccessAt:latest?.email_at??null}]:[])];
      return json({checkedAt:Date.now(),database:"available",pinConfigured:Boolean(env.PIN_HASH&&env.SESSION_SECRET),ai:{configured:ready.ai,provider:config.aiProvider,model:selectedAiModel(config),lastSuccessAt:latest?.ai_at??null},notifications:{configured:ready.notifications,provider:config.notificationProvider,lastSuccessAt:Math.max(0,...channels.map(v=>v.lastSuccessAt||0))||null,channels}});
    }
    if(path==="/api/session"&&method==="POST") {
      secret(env); await rateLimit(request,env,"pin",8,15*60000);
      const data=await body(request);
      if(!/^\d{6}$/.test(data.pin||"")||await hash(`${secret(env)}:${data.pin}`)!==env.PIN_HASH) throw new HttpError(401,"Nepareizs PIN kods.");
      const token=randomToken();
      await database.prepare("INSERT INTO sessions(token_hash,expires_at) VALUES (?,?)").bind(await hash(token),Date.now()+sessionAge*1000).run();
      return json({ok:true},200,{"Set-Cookie":`${cookieName}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${sessionAge}`});
    }
    if(path==="/api/session"&&method==="GET") return json({authenticated:await session(request,env)});
    if(path==="/api/session"&&method==="DELETE") {
      await authorize(request,env);
      const token=request.headers.get("cookie")?.match(/(?:^|;\s*)lead_session=([a-f0-9]{64})(?:;|$)/)?.[1];
      if(token) await database.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await hash(token)).run();
      return json({ok:true},200,{"Set-Cookie":`${cookieName}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`});
    }
    if(path==="/api/leads"&&method==="POST") {
      secret(env);
      const parsed=leadInput.safeParse(await body(request));
      if(!parsed.success) throw new HttpError(422,"Pārbaudi atzīmētos laukus.",{fields:parsed.error.flatten().fieldErrors});
      const value=parsed.data;
      if(value.website) throw new HttpError(422,"Pieteikumu nevarēja nosūtīt.");
      const existing=await database.prepare("SELECT id FROM leads WHERE submission_id=?").bind(value.submissionId).first<{id:string}>();
      if(existing) return json({ok:true,id:existing.id,duplicate:true});
      await rateLimit(request,env,"submit-minute",8,60000); await rateLimit(request,env,"submit-hour",60,60*60000);
      const id=crypto.randomUUID(),now=Date.now();
      const inserted=await database.prepare("INSERT INTO leads(id,submission_id,name,phone,email,company,industry,revenue,goal,created_at,updated_at,consent_at,email_state) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'pending') ON CONFLICT(submission_id) DO NOTHING RETURNING id").bind(id,value.submissionId,value.name,value.phone,value.email,value.company,value.industry,value.revenue,value.goal,now,now,value.consent?now:0).first<{id:string}>();
      const actualId=inserted?.id||(await database.prepare("SELECT id FROM leads WHERE submission_id=?").bind(value.submissionId).first<{id:string}>())?.id;
      if(!actualId) throw new HttpError(500,"Neizdevās saglabāt pieteikumu.");
      if(inserted) background(ctx,processLead(id,env,url.origin));
      return json({ok:true,id:actualId},201);
    }
    await authorize(request,env);
    if(path==="/api/leads"&&method==="GET") {
      const result=await database.prepare("SELECT * FROM leads ORDER BY created_at DESC,id DESC LIMIT 1000").all<Lead>();
      background(ctx,resumePending(env,url.origin));
      return json({leads:result.results,integrations:readiness(await getIntegrations(env)),limit:1000,serverTime:Date.now()});
    }
    const match=path.match(/^\/api\/leads\/([a-f0-9-]{36})(\/retry)?$/);
    if(match&&method==="PATCH"&&!match[2]) {
      const data=z.object({status:z.enum(STATUSES).optional(),notes:z.string().trim().max(3000).optional()}).refine(v=>v.status!==undefined||v.notes!==undefined).parse(await body(request));
      const updated=await database.prepare("UPDATE leads SET status=COALESCE(?,status),notes=COALESCE(?,notes),updated_at=? WHERE id=? RETURNING *").bind(data.status??null,data.notes??null,Date.now(),match[1]).first<Lead>();
      if(!updated) throw new HttpError(404,"Līds nav atrasts.");
      return json({lead:updated});
    }
    if(match&&method==="POST"&&match[2]) {
      const changed=await database.prepare("UPDATE leads SET ai_state=CASE WHEN ai_state='done' THEN ai_state ELSE 'pending' END,notification_state=CASE WHEN notification_state='sent' THEN notification_state ELSE 'pending' END,email_state=CASE WHEN email_state='sent' THEN email_state ELSE 'pending' END WHERE id=? AND lease_until<? RETURNING id").bind(match[1],Date.now()).first();
      if(!changed) throw new HttpError(409,"Apstrāde jau notiek vai līds nav atrasts.");
      background(ctx,processLead(match[1],env,url.origin)); return json({ok:true});
    }
    if(path==="/api/settings"&&method==="GET") {
      const config=await getIntegrations(env);
      return json({...readiness(config),openaiModel:config.aiModel,groqModel:config.groqModel,hasGroqKey:Boolean(config.groqKey),telegramChatId:config.telegramChatId,hasTelegramToken:Boolean(config.telegramToken),hasDiscordWebhook:Boolean(config.discordWebhook),hasAiKey:Boolean(config.aiKey),hasResendKey:Boolean(config.resendKey),emailFrom:config.emailFrom,emailTo:config.emailTo});
    }
    if(path==="/api/settings"&&method==="POST") {
      await rateLimit(request,env,"settings",20,60000);
      const parsed=z.object({aiProvider:z.enum(["openai","groq"]).optional(),aiKey:z.string().trim().max(512).optional(),groqKey:z.string().trim().max(512).optional(),aiModel:z.string().trim().min(1).max(80).regex(/^[a-zA-Z0-9._:/-]+$/),notificationProvider:z.enum(["telegram","discord"]),telegramToken:z.string().trim().max(250).optional(),telegramChatId:z.string().trim().max(100),discordWebhook:z.string().trim().max(500).optional(),messengerEnabled:z.boolean().optional(),emailEnabled:z.boolean().optional(),resendKey:z.string().trim().max(512).optional(),emailFrom:z.union([z.string().trim().max(254).email(),z.literal("")]).optional(),emailTo:z.union([z.string().trim().max(254).email(),z.literal("")]).optional()}).parse(await body(request));
      if(parsed.aiKey&&!/^sk-[A-Za-z0-9_-]+$/.test(parsed.aiKey)) throw new HttpError(422,"Pārbaudi OpenAI API atslēgu.");
      if(parsed.groqKey&&!/^gsk_[A-Za-z0-9_-]+$/.test(parsed.groqKey))throw new HttpError(422,"Pārbaudi Groq API atslēgu. Tai jāsākas ar gsk_.");
      if(parsed.telegramToken&&!/^\d+:[A-Za-z0-9_-]+$/.test(parsed.telegramToken)) throw new HttpError(422,"Pārbaudi Telegram bota atslēgu.");
      if(parsed.telegramChatId&&!/^(?:-?\d+|@[A-Za-z0-9_]{5,})$/.test(parsed.telegramChatId)) throw new HttpError(422,"Pārbaudi Telegram Chat ID.");
      if(parsed.discordWebhook&&!/^https:\/\/discord(?:app)?\.com\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+$/.test(parsed.discordWebhook)) throw new HttpError(422,"Ievadi Discord webhook saiti bez papildu parametriem.");
      if(parsed.resendKey&&!/^re_[A-Za-z0-9_-]+$/.test(parsed.resendKey)) throw new HttpError(422,"Pārbaudi Resend API atslēgu.");
      const config=await getIntegrations(env);
      const aiProvider=parsed.aiProvider??config.aiProvider;
      const updated: Integrations={...config,aiProvider,aiModel:aiProvider==="openai"?parsed.aiModel:config.aiModel,groqModel:aiProvider==="groq"?parsed.aiModel:config.groqModel,groqKey:parsed.groqKey||config.groqKey,notificationProvider:parsed.notificationProvider,telegramChatId:parsed.telegramChatId,aiKey:parsed.aiKey||config.aiKey,telegramToken:parsed.telegramToken||config.telegramToken,discordWebhook:parsed.discordWebhook||config.discordWebhook,messengerEnabled:parsed.messengerEnabled??config.messengerEnabled,emailEnabled:parsed.emailEnabled??config.emailEnabled,resendKey:parsed.resendKey||config.resendKey,emailFrom:parsed.emailFrom??config.emailFrom,emailTo:parsed.emailTo??config.emailTo};
      await database.prepare("INSERT INTO settings(id,sealed,updated_at) VALUES ('integrations',?,?) ON CONFLICT(id) DO UPDATE SET sealed=excluded.sealed,updated_at=excluded.updated_at").bind(await seal(updated,env),Date.now()).run();
      return json({ok:true,...readiness(updated)});
    }
    if(path==="/api/settings/telegram-chats"&&method==="POST") {
      await rateLimit(request,env,"telegram-chats",6,60000);
      const config=await getIntegrations(env);
      if(!config.telegramToken) throw new HttpError(422,"Vispirms saglabā bota atslēgu.");
      const response=await serviceFetch(`https://api.telegram.org/bot${config.telegramToken}/getUpdates?limit=30`,{signal:AbortSignal.timeout(7000)},"Telegram");
      if(!response.ok) throw new HttpError(422,"Telegram čatu nevar nolasīt. Pārbaudi bota atslēgu vai ievadi Chat ID pats.");
      const data=await response.json() as {ok:boolean;result?:{message?:{chat?:{id:number;title?:string;first_name?:string}};channel_post?:{chat?:{id:number;title?:string}}}[]};
      const chats=new Map<string,{id:string;name:string}>();
      for(const update of data.result||[]){const chat=update.message?.chat||update.channel_post?.chat;if(chat)chats.set(String(chat.id),{id:String(chat.id),name:chat.title||("first_name" in chat&&typeof chat.first_name==="string"?chat.first_name:"")||String(chat.id)});}
      return json({chats:[...chats.values()]});
    }
    if(path==="/api/settings/test"&&method==="POST") {
      await rateLimit(request,env,"integration-test",6,60000);
      const {target}=z.object({target:z.enum(["ai","notifications","email"])}).parse(await body(request));
      const config=await getIntegrations(env),ready=readiness(config);
      if(target==="ai") {
        if(!ready.ai) throw new HttpError(422,"Vispirms saglabā AI atslēgu.");
        const result=await evaluate({company:"Pārbaudes uzņēmums",industry:"Pakalpojumi",revenue:"10 000–50 000 €",goal:"Vēlamies 30 dienu laikā ieviest automātisku pieteikumu apstrādi. Ir 1500 eiro budžets, gribam sākt šonedēļ."},config);
        return json({ok:true,message:`AI strādā. Testa vērtējums: ${result.rating}. ${result.reason}`});
      }
      if(target==="email"){
        if(!config.emailEnabled||!ready.emailReady)throw new HttpError(422,"Vispirms ieslēdz e-pastu un saglabā atslēgu, sūtītāju un saņēmēju.");
        await sendEmail(`LEAD INBOX · Savienojuma pārbaude\n\nJauno līdu paziņojumi tiks sūtīti uz šo adresi.\n${url.origin}/inbox`,"Lead Inbox · testa paziņojums",config,`test-${crypto.randomUUID()}`);
        return json({ok:true,message:"Resend pieņēma testa e-pastu. Pārbaudi saņēmēja iesūtni un mēstuļu mapi."});
      }
      if(!config.messengerEnabled||!ready.messengerReady) throw new HttpError(422,"Vispirms ieslēdz un pieslēdz Telegram vai Discord.");
      await notify(`LEAD INBOX · Savienojuma pārbaude\n\nPaziņojumi ir pieslēgti. Jaunie līdi tiks sūtīti šeit.\n${url.origin}/inbox`,config);
      return json({ok:true,message:"Testa paziņojums pieņemts servisā. Pārbaudi izvēlēto kanālu."});
    }
    throw new HttpError(404,"Nav atrasts.");
  } catch(error) {
    if(error instanceof HttpError) return json({error:error.message,...error.extra},error.status,error.status===429?{"Retry-After":String(error.extra.retryAfterSeconds||60)}:{});
    if(error instanceof z.ZodError) return json({error:"Pārbaudi ievadītos datus.",fields:error.flatten().fieldErrors},422);
    console.error("Lead Inbox API error",path,error instanceof Error?error.name:"unknown");
    return json({error:errorMessage(error)},500);
  }
}

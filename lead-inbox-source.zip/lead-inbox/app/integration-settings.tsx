"use client";
import {useCallback,useEffect,useState,type FormEvent} from "react";
import {Sparkles,MessageSquare,Mail,Search,ShieldCheck,Check} from "lucide-react";
import {api,Spinner} from "./components";

type Config={ai:boolean;aiProvider:"openai"|"groq";aiModel:string;openaiModel:string;groqModel:string;hasGroqKey:boolean;messengerEnabled:boolean;emailEnabled:boolean;customerEmailEnabled:boolean;customerEmailReady:boolean;emailTestSender:boolean;messengerReady:boolean;emailReady:boolean;telegramChatId:string;telegramChatTitle?:string;telegramChatType?:string;telegramVerifiedAt?:number;hasAiKey:boolean;hasTelegramToken:boolean;hasResendKey:boolean;emailFrom:string;emailTo:string};
type Chat={id:string;name:string;type:string};
type Scope="all"|"ai"|"telegram"|"telegram-token"|"email";
type Test="ai"|"notifications"|"email"|"chats";

export function IntegrationSettings({onChange,onMessage}:{onChange:()=>void;onMessage:(s:string)=>void}){
  const [config,setConfig]=useState<Config|null>(null),[aiKey,setAiKey]=useState(""),[model,setModel]=useState("gpt-4.1-mini"),[token,setToken]=useState(""),[chatId,setChatId]=useState("");
  const [aiProvider,setAiProvider]=useState<"openai"|"groq">("groq"),[groqKey,setGroqKey]=useState("");
  const [messengerEnabled,setMessengerEnabled]=useState(true),[emailEnabled,setEmailEnabled]=useState(false),[customerEmailEnabled,setCustomerEmailEnabled]=useState(true),[resendKey,setResendKey]=useState(""),[emailFrom,setEmailFrom]=useState(""),[emailTo,setEmailTo]=useState("");
  const [busy,setBusy]=useState(false),[testing,setTesting]=useState<Test|"">(""),[error,setError]=useState(""),[result,setResult]=useState(""),[chats,setChats]=useState<Chat[]>([]);
  const [messageScope,setMessageScope]=useState<Test|"all">("all");
  const locked=busy||Boolean(testing);
  const load=useCallback(async(hydrate=true)=>{
    const data=await api<Config>("/api/settings");setConfig(data);
    if(hydrate){setAiProvider(data.aiProvider||"openai");setModel(data.aiModel);setChatId(data.telegramChatId);setMessengerEnabled(data.messengerEnabled);setEmailEnabled(data.emailEnabled);setCustomerEmailEnabled(data.customerEmailEnabled);setEmailFrom(data.emailFrom);setEmailTo(data.emailTo);}
    return data;
  },[]);
  useEffect(()=>{load().catch(err=>setError(err.message));},[load]);
  const dirty=Boolean(config&&(aiKey||groqKey||aiProvider!==config.aiProvider||token||resendKey||model!==config.aiModel||chatId!==config.telegramChatId||messengerEnabled!==config.messengerEnabled||emailEnabled!==config.emailEnabled||customerEmailEnabled!==config.customerEmailEnabled||emailFrom!==config.emailFrom||emailTo!==config.emailTo));

  async function persist(scope:Scope,destination=chatId){
    const payload:Record<string,unknown>={};
    if(scope==="all"||scope==="ai")Object.assign(payload,{aiProvider,aiKey,groqKey,aiModel:model});
    if(scope==="all"||scope==="telegram")Object.assign(payload,{telegramToken:token,telegramChatId:destination,messengerEnabled});
    if(scope==="telegram-token")Object.assign(payload,{telegramToken:token});
    if(scope==="all"||scope==="email")Object.assign(payload,{emailEnabled,customerEmailEnabled,resendKey,emailFrom,emailTo});
    await api("/api/settings",{method:"POST",body:JSON.stringify(payload)});
    if(scope==="all"||scope==="ai"){setAiKey("");setGroqKey("");}
    if(scope==="all"||scope==="telegram"||scope==="telegram-token")setToken("");
    if(scope==="all"||scope==="email")setResendKey("");
    const saved=await load(false);onChange();return saved;
  }
  async function save(event:FormEvent){
    event.preventDefault();setBusy(true);setMessageScope("all");setError("");setResult("");
    try{await persist("all");onMessage("Savienojumi saglabāti.");}
    catch(err){setError(err instanceof Error?err.message:"Neizdevās saglabāt.");}
    finally{setBusy(false);}
  }
  async function selectGroup(chat:Chat){
    setBusy(true);setMessageScope("chats");setError("");setResult("");
    try{await persist("telegram",chat.id);setChatId(chat.id);setChats([]);setResult(`Grupa “${chat.name}” izvēlēta un saglabāta. Nosūti testa paziņojumu.`);}
    catch(err){setError(err instanceof Error?err.message:"Grupu neizdevās saglabāt.");}
    finally{setBusy(false);}
  }
  async function runTest(target:Test){
    setTesting(target);setMessageScope(target);setError("");setResult("");
    try{
      // Save only this section. A draft email or AI field cannot block Telegram.
      await persist(target==="chats"?"telegram-token":target==="notifications"?"telegram":target);
      if(target==="chats"){
        const data=await api<{chats:Chat[];selectedChatId:string}>("/api/settings/telegram-chats",{method:"POST",body:JSON.stringify({groupsOnly:true}),signal:AbortSignal.timeout(12000)});
        const group=data.chats.length===1?data.chats[0]:undefined;
        if(group){await persist("telegram",group.id);setChatId(group.id);setChats([]);setResult(`Grupa “${group.name}” atrasta un saglabāta. Nosūti testa paziņojumu.`);}
        else {setChats(data.chats);setResult(data.chats.length?"Izvēlies grupu zemāk. Izvēle saglabāsies uzreiz.":"Grupa vēl nav atrasta. Pievieno botu savai grupai, grupā nosūti /start un spied “Atrast grupu” vēlreiz. Vari arī ievadīt grupas Chat ID manuāli.");}
      }else{
        const data=await api<{message:string}>("/api/settings/test",{method:"POST",body:JSON.stringify({target}),signal:AbortSignal.timeout(27000)});
        const saved=await load(false);
        if(target==="notifications"){setChatId(saved.telegramChatId);setChats([]);}
        setResult(data.message);
      }
    }catch(err){setError(err instanceof Error?err.message:"Pārbaude neizdevās.");}
    finally{setTesting("");}
  }

  const feedback=<>{error&&<div className="notice notice-error" role="alert">{error}</div>}{result&&<div className="notice notice-success" role="status">{result}</div>}</>;
  return <main className="settings-content"><div className="page-heading"><div><div className="eyebrow muted">VISS SAVĀ VIETĀ</div><h1>Savienojumi<span>.</span></h1><p>AI novērtējums un paziņojumi Telegram un e-pastā.</p></div></div>
    {messageScope==="all"&&feedback}
    {!config?(error?<button className="button button-outline" onClick={()=>{setError("");load().catch(err=>setError(err.message));}}>Mēģināt vēlreiz</button>:<div className="empty-state"><Spinner/></div>):<form onSubmit={save} className="settings-form">
      <p className="settings-help">Pārbaudes pogas pašas saglabā attiecīgās sadaļas izmaiņas. Atsevišķi nospiest “Saglabāt savienojumus” nav nepieciešams.</p>
      <fieldset disabled={locked} className="settings-controls">
      <section className="settings-card"><div className="settings-card-heading"><span className="settings-icon"><Sparkles size={22}/></span><div><h2>AI novērtējums</h2><p>Prioritāte, iemesls un sarunas sākums</p></div><span className={`connection-badge ${config.ai?"connected":""}`}>{config.ai?`${config.aiProvider==="groq"?"Groq":"OpenAI"} atslēga saglabāta`:"Nav pieslēgts"}</span></div>
        <label htmlFor="ai-provider">AI pakalpojums<select id="ai-provider" value={aiProvider} onChange={event=>{const next=event.target.value as "openai"|"groq";setAiProvider(next);setModel(next==="groq"?config.groqModel:config.openaiModel);setResult("");setError("");}}><option value="groq">Groq · pieejama bezmaksas kvota</option><option value="openai">OpenAI · nepieciešams API kredīts</option></select></label>
        <div className="settings-fields"><label htmlFor={aiProvider==="groq"?"groq-key":"ai-key"}>{aiProvider==="groq"?"Groq":"OpenAI"} API atslēga<input type="password" id={aiProvider==="groq"?"groq-key":"ai-key"} autoComplete="new-password" value={aiProvider==="groq"?groqKey:aiKey} onChange={event=>aiProvider==="groq"?setGroqKey(event.target.value):setAiKey(event.target.value)} placeholder={(aiProvider==="groq"?config.hasGroqKey:config.hasAiKey)?"Saglabāta · atstāj tukšu, lai paturētu":aiProvider==="groq"?"gsk_…":"sk-…"}/></label><label htmlFor="model">Modelis<input id="model" value={model} onChange={e=>setModel(e.target.value)} required maxLength={80}/></label></div>
        <div className="integration-ai-actions"><button type="button" className="button button-small button-outline" onClick={()=>runTest("ai")}>{testing==="ai"?<Spinner/>:<Sparkles size={15}/>}Pārbaudīt AI savienojumu</button></div>
        {messageScope==="ai"&&feedback}
        {aiProvider==="groq"?<div className="setup-steps"><strong>Pieslēgšana ar bezmaksas kvotu</strong><ol><li>Atver <a href="https://console.groq.com/keys" target="_blank" rel="noreferrer">Groq API Keys</a> un izveido atslēgu Free kontā.</li><li>Ielīmē to Groq laukā un spied “Pārbaudīt AI savienojumu”.</li><li>Iesniedz testa līdu un pārbaudi vērtējumu inbox.</li></ol><p>Bezmaksas kvotai ir limiti. Sasniedzot limitu, pieteikums paliek saglabāts un apstrādi var atkārtot pēc kvotas atjaunošanās.</p></div>:<p className="settings-help">Izveido atslēgu <a href="https://platform.openai.com/api-keys" target="_blank" rel="noreferrer">OpenAI API projektā</a> ar pieejamu API kredītu. API norēķini ir atsevišķi no ChatGPT Plus.</p>}
        <p className="settings-help">AI saņem uzņēmumu, nozari, apgrozījumu un mērķi. Vārdu, telefonu un e-pastu pieprasījuma laukos neiekļauj.</p>
      </section>

      <section className="settings-card"><div className="settings-card-heading"><span className="settings-icon"><MessageSquare size={22}/></span><div><h2>Telegram grupa</h2><p>Visi grupas dalībnieki redz jaunos līdus</p></div><span className={`connection-badge ${config.messengerEnabled&&config.messengerReady?"connected":""}`}>{!config.messengerEnabled?"Izslēgts":config.telegramVerifiedAt?"Piegāde pārbaudīta":config.messengerReady?"Grupa saglabāta":"Nav pieslēgts"}</span></div>
        <label className="integration-toggle"><input type="checkbox" checked={messengerEnabled} onChange={e=>setMessengerEnabled(e.target.checked)}/><span>Sūtīt jaunos līdus uz Telegram</span></label>
        {config.messengerReady&&<div className="telegram-destination"><MessageSquare size={20}/><div><strong>{config.telegramChatTitle||`Izvēlētais čats: ${config.telegramChatId}`}</strong><p>{config.telegramVerifiedAt?"Telegram ir apstiprinājis ziņas pieņemšanu šajā čatā.":"Nosūti testu, lai pārbaudītu bota piekļuvi un parādītu grupas nosaukumu."}</p></div></div>}
        <div className="settings-fields"><label htmlFor="bot-token">Telegram bota atslēga<input type="password" id="bot-token" autoComplete="new-password" value={token} onChange={e=>setToken(e.target.value)} placeholder={config.hasTelegramToken?"Saglabāta · vari atstāt tukšu":"123456789:AA…"}/></label><label htmlFor="chat-id">Grupas Chat ID<input id="chat-id" value={chatId} onChange={e=>setChatId(e.target.value)} placeholder="Atrodi grupu ar pogu zemāk vai ievadi ID"/></label></div>
        <div className="integration-ai-actions">
          <button type="button" className="button button-small button-outline" onClick={()=>runTest("chats")}>{testing==="chats"?<Spinner/>:<Search size={15}/>}Atrast grupu</button>
          <button type="button" className="button button-small button-primary" onClick={()=>runTest("notifications")}>{testing==="notifications"?<Spinner/>:<MessageSquare size={15}/>}Nosūtīt testa paziņojumu</button>
        </div>
        {chats.length>0&&<label htmlFor="telegram-group">Izvēlies grupu<select id="telegram-group" value="" onChange={e=>{const chat=chats.find(value=>value.id===e.target.value);if(chat)void selectGroup(chat);}}><option value="">Izvēlies grupu</option>{chats.map(chat=><option key={chat.id} value={chat.id}>{chat.name} ({chat.id})</option>)}</select></label>}
        {(messageScope==="notifications"||messageScope==="chats")&&feedback}
        <p className="settings-help">Paziņojumi nonāk vienā izvēlētajā grupā. Dalībniekiem pietiek tai pievienoties ar grupas uzaicinājuma saiti; privātajā bota čatā kopiju nesūta.</p>
        <details className="telegram-help"><summary>Kā pieslēgt vai nomainīt grupu?</summary><div className="setup-steps"><ol><li>Ja vajadzīgs jauns bots, izveido to pie <a href="https://t.me/BotFather" target="_blank" rel="noreferrer">@BotFather</a> ar <code>/newbot</code> un ielīmē atslēgu augšā.</li><li>Pievieno botu savai Telegram grupai un atļauj tam sūtīt ziņas. Ja dalībniekiem rakstīšana ir aizliegta, piešķir botam administratora tiesības ar nepieciešamo ziņu sūtīšanas atļauju.</li><li>Grupā nosūti <code>/start</code>, šeit spied “Atrast grupu” un izvēlies to, ja atrodamas vairākas. Izvēle saglabājas uzreiz.</li><li>Spied “Nosūtīt testa paziņojumu” un atver grupu. Grupas uzaicinājuma saiti vari pievienot projekta aprakstam; Chat ID laukā to nelīmē.</li></ol></div></details>
      </section>

      <section className="settings-card"><div className="settings-card-heading"><span className="settings-icon"><Mail size={22}/></span><div><h2>E-pasta paziņojumi</h2><p>Resend · darbojas arī kopā ar Telegram</p></div><span className={`connection-badge ${config.emailEnabled&&config.emailReady?"connected":""}`}>{!config.emailEnabled?"Izslēgts":config.emailReady?"Dati saglabāti":"Nav pieslēgts"}</span></div>
        <label className="integration-toggle"><input type="checkbox" checked={emailEnabled} onChange={e=>setEmailEnabled(e.target.checked)}/><span>Sūtīt jaunos līdus pārdevēja e-pastā</span></label>
        <label className="integration-toggle"><input type="checkbox" checked={customerEmailEnabled} onChange={e=>setCustomerEmailEnabled(e.target.checked)}/><span>Sūtīt klientam pieteikuma apstiprinājumu</span></label>
        <label htmlFor="resend-key">Resend API atslēga<input type="password" id="resend-key" autoComplete="new-password" value={resendKey} onChange={e=>setResendKey(e.target.value)} placeholder={config.hasResendKey?"Saglabāta · vari atstāt tukšu":"re_…"}/></label><div className="settings-fields"><label htmlFor="email-from">Sūtītāja e-pasts<input id="email-from" type="email" maxLength={254} value={emailFrom} onChange={e=>setEmailFrom(e.target.value)} placeholder="lidi@tavs-domens.lv"/></label><label htmlFor="email-to">Saņēmēja e-pasts<input id="email-to" type="email" maxLength={254} value={emailTo} onChange={e=>setEmailTo(e.target.value)} placeholder="tavs@epasts.lv"/></label></div>
        <button type="button" className="button button-small button-outline" onClick={()=>runTest("email")}>{testing==="email"?<Spinner/>:<Mail size={15}/>}Nosūtīt testa e-pastu</button>
        {messageScope==="email"&&feedback}
        <div className="setup-steps"><strong>Ātrā pieslēgšana</strong><ol><li><a href="https://resend.com/api-keys" target="_blank" rel="noreferrer">Resend</a> izveido atslēgu ar e-pastu sūtīšanas tiesībām.</li><li>Izmanto sūtītāju no sava <a href="https://resend.com/domains" target="_blank" rel="noreferrer">Resend apstiprinātā domēna</a>.</li><li>Testa sūtītājs <code>onboarding@resend.dev</code> drīkst sūtīt tikai uz tava Resend konta e-pastu.</li><li>Spied “Nosūtīt testa e-pastu”. Izmaiņas saglabāsies automātiski. Pārbaudi arī mēstuļu mapi.</li></ol></div>
        <p className="settings-help">Saņēmējs ir komandas adrese un adrese klienta atbildēm. Klienta apstiprinājums nonāk formā norādītajā e-pastā; tajā nav AI vērtējuma vai inbox piekļuves.</p>
        {customerEmailEnabled&&config.emailTestSender&&<p className="notice notice-error" role="status">Klientu apstiprinājumiem vajadzīgs Resend apstiprināts sūtītāja domēns. Testa sūtītājs var sūtīt tikai uz tava Resend konta e-pastu. Pieteikumi joprojām saglabājas.</p>}
      </section>
      <div className="settings-save"><p><ShieldCheck size={17}/>Atslēgas saglabā šifrētas un neatgriež pārlūkam.</p><button className="button button-primary">{busy?<Spinner/>:<Check size={17}/>}Saglabāt savienojumus</button></div>
      </fieldset>
      <p className="settings-help" role="status">{dirty?"Ir izmaiņas. Vari uzreiz nospiest attiecīgās sadaļas pārbaudes pogu vai saglabāt visus savienojumus.":"Iesniedz vienu testa līdu formā un pārbaudi, ka tas ar AI vērtējumu ir inbox un izvēlētajā grupā. Saglabāta atslēga viena pati neapliecina piegādi."}</p>
      <p className="settings-help">E-pasta ieslēgšana nesūta ziņas vēsturiskajiem līdiem. Lai atkārtotu konkrēta līda neizdevušos apstrādi, atver to inbox un nospied “Atkārtot neizdevušos apstrādi”.</p>
    </form>}
  </main>;
}

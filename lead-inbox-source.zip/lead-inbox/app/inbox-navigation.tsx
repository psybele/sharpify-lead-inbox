"use client";
import {useCallback,useEffect,useRef,useState} from "react";
import {Archive,Inbox,LogOut,Menu,Plus,Settings2,X} from "lucide-react";
import {Brand} from "./components";
import {STATUSES} from "../lib/leads-domain";

type NavigationProps={
  view:string;status:string;counts:Record<string,number>;archivedCount:number;
  onView:(view:string)=>void;onStatus:(status:string)=>void;onLogout:()=>void;onOpenForm?:()=>void;
};

function NavigationContent({view,status,counts,archivedCount,onView,onStatus,onLogout,onOpenForm}:NavigationProps){
  return <>
    <nav className="sidebar-navigation" aria-label="Inbox navigācija">
      <div className="sidebar-label">DARBA VIETA</div>
      <button className={`side-item ${view==="inbox"?"active":""}`} aria-current={view==="inbox"?"page":undefined} onClick={()=>onView("inbox")}><Inbox size={19}/>Līdu inbox<span>{counts.Jauns||0}</span></button>
      <div className="sidebar-label status-side-label">STATUSI</div>
      <div className="status-nav">{["Visi",...STATUSES].map(value=><button key={value} className={`status-nav-item ${status===value&&view==="inbox"?"chosen":""}`} aria-pressed={status===value&&view==="inbox"} onClick={()=>onStatus(value)}><span aria-hidden="true" className={`status-dot dot-${STATUSES.indexOf(value as typeof STATUSES[number])}`}/>{value}<span>{counts[value]||0}</span></button>)}</div>
    </nav>
    <div className="sidebar-bottom">
      <button className={`side-item ${view==="archive"?"active":""}`} aria-current={view==="archive"?"page":undefined} onClick={()=>onView("archive")}><Archive size={18}/>Arhīvs<span>{archivedCount}</span></button>
      <button className={`side-item ${view==="settings"?"active":""}`} aria-current={view==="settings"?"page":undefined} onClick={()=>onView("settings")}><Settings2 size={18}/>Savienojumi</button>
      <a href="/" target="_blank" rel="noreferrer" className="side-item" onClick={onOpenForm}><Plus size={18}/>Atvērt formu</a>
      <div className="user-block"><span className="user-avatar">MS</span><div><strong>Pārdevēja telpa</strong><small>PIN aizsargāta piekļuve</small></div><button onClick={onLogout} className="icon-button" aria-label="Iziet"><LogOut size={18}/></button></div>
    </div>
  </>;
}

export function InboxSidebar(props:NavigationProps){
  return <aside className="sidebar" aria-label="Galvenā izvēlne"><Brand dark/><NavigationContent {...props}/></aside>;
}

export function MobileInboxMenu(props:NavigationProps){
  const [open,setOpen]=useState(false),dialogRef=useRef<HTMLDialogElement>(null),closeRef=useRef<HTMLButtonElement>(null);
  const close=useCallback(()=>{dialogRef.current?.close();setOpen(false);},[]);
  useEffect(()=>{
    if(!open)return;
    const previousOverflow=document.body.style.overflow;
    document.body.style.overflow="hidden";
    const desktop=window.matchMedia("(min-width: 651px)");
    const onResize=()=>{if(desktop.matches)close();};
    desktop.addEventListener("change",onResize);
    return()=>{document.body.style.overflow=previousOverflow;desktop.removeEventListener("change",onResize);};
  },[open,close]);
  function show(){if(dialogRef.current&&!dialogRef.current.open){dialogRef.current.showModal();setOpen(true);closeRef.current?.focus();}}
  const actions={
    ...props,
    onView:(view:string)=>{props.onView(view);close();},
    onStatus:(status:string)=>{props.onStatus(status);close();},
    onLogout:()=>{close();props.onLogout();},
    onOpenForm:close,
  };
  return <>
    <header className="mobile-nav"><Brand/><button className="button button-small button-outline mobile-menu-trigger" aria-haspopup="dialog" aria-controls="mobile-inbox-navigation" aria-expanded={open} onClick={show}><Menu size={20}/><span>Izvēlne</span></button></header>
    <dialog id="mobile-inbox-navigation" ref={dialogRef} className="mobile-sidebar-dialog" aria-labelledby="mobile-menu-title" onClose={()=>setOpen(false)} onKeyDown={event=>{
      if(event.key!=="Tab")return;
      const items=Array.from(event.currentTarget.querySelectorAll<HTMLElement>('a[href],button:not([disabled])')).filter(element=>element.getClientRects().length>0);
      const first=items[0],last=items[items.length-1],active=event.currentTarget.ownerDocument.activeElement;
      if(event.shiftKey&&active===first){event.preventDefault();last?.focus();}
      else if(!event.shiftKey&&active===last){event.preventDefault();first?.focus();}
    }} onClick={event=>{
      if(event.target!==event.currentTarget)return;
      const rect=event.currentTarget.getBoundingClientRect();
      if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)close();
    }}>
      <div className="mobile-sidebar-panel"><div className="mobile-sidebar-heading"><Brand dark/><button ref={closeRef} className="icon-button" aria-label="Aizvērt izvēlni" onClick={close}><X size={22}/></button></div><h2 id="mobile-menu-title" className="sr-only">Izvēlne</h2><NavigationContent {...actions}/></div>
    </dialog>
  </>;
}

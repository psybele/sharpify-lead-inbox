import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lead Inbox · No pieteikuma līdz sarunai",
  description: "Pastāsti par sava uzņēmuma mērķi. Pieteikumi vienuviet, ātra saziņa un skaidras prioritātes.",
  robots: { index: false, follow: false },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="lv">
      <body className="antialiased">{children}</body>
    </html>
  );
}

"use client";
import { useRef,useState,type FormEvent } from "react";
import { Check,CheckCheck,Clock3,LockKeyhole,MessageSquare,ShieldCheck } from "lucide-react";
import { Brand,Spinner,api,ApiError } from "./components";
import { INDUSTRIES,REVENUES,leadInput } from "../lib/leads-domain";

export default function Home() {
  const submissionId=useRef("");
  const [busy,setBusy]=useState(false),[receipt,setReceipt]=useState(""),[error,setError]=useState(""),[fields,setFields]=useState<Record<string,string[]>>({});
  const [confirmation,setConfirmation]=useState("");
  async function submit(event:FormEvent<HTMLFormElement>) {
    event.preventDefault(); if(busy) return;
    const form=event.currentTarget,values=Object.fromEntries(new FormData(form));
    if(!submissionId.current) submissionId.current=crypto.randomUUID();
    const payload={...values,submissionId:submissionId.current};
    const parsed=leadInput.safeParse(payload);
    setFields({});setError("");
    if(!parsed.success) {
      const errors=parsed.error.flatten().fieldErrors;setFields(errors);setError("Pārbaudi atzīmētos laukus.");
      (form.elements.namedItem(Object.keys(errors)[0]) as HTMLElement)?.focus();return;
    }
    setBusy(true);
    try {const data=await api<{id:string;confirmation:string}>("/api/leads",{method:"POST",body:JSON.stringify(payload)});setReceipt(data.id);setConfirmation(data.confirmation);window.scrollTo({top:0,behavior:"smooth"});}
    catch(err) {setError(err instanceof Error?err.message:"Neizdevās nosūtīt.");if(err instanceof ApiError&&err.fields)setFields(err.fields);}
    finally {setBusy(false);}
  }
  function fieldError(name:string) {return fields[name]?<span id={`${name}-error`} className="field-error">{fields[name][0]}</span>:null;}
  const props=(name:string)=>({name,id:name,"aria-invalid":Boolean(fields[name]),"aria-describedby":fields[name]?`${name}-error`:undefined});
  return <div className="public-page">
    <header className="public-header"><Brand/><a href="/inbox" className="button button-ghost"><LockKeyhole size={16}/><span>Pārdevēja inbox</span></a></header>
    <main className="public-main">
      <section className="intro-panel">
        <div className="eyebrow"><span className="little-line"/>NO PIETEIKUMA LĪDZ SARUNAI</div>
        <h1>Lielas lietas<br/>sākas ar<br/>{" "}<span>sarunu.</span></h1>
        <p className="intro-text">Pastāsti, kur esi šobrīd un ko vēlies sasniegt. Atradīsim nākamo soli tava uzņēmuma izaugsmei.</p>
        <div className="intro-benefits"><div><span><MessageSquare size={19}/></span><p><strong>Tavs mērķis centrā</strong><small>Konkrēta vajadzība. Jēgpilna saruna.</small></p></div><div><span><Clock3 size={19}/></span><p><strong>Pieteikums pāris minūtēs</strong><small>Tikai svarīgākais par tevi un uzņēmumu.</small></p></div></div>
        <div className="signal-art" aria-hidden="true"><div className="signal-orbit orbit-one"/><div className="signal-orbit orbit-two"/><span className="signal-dot dot-one"/><span className="signal-dot dot-two"/><div className="signal-core"><MessageSquare size={34}/><span className="core-check"><Check size={16}/></span></div><span className="signal-caption">Labs sākums. Skaidrs virziens.</span></div>
        <div className="intro-footer">Mazāk gaidīšanas. Vairāk īstu sarunu.</div>
      </section>
      <section className="form-section" aria-label="Pieteikuma forma">
        {receipt?<div className="success-view"><span className="success-icon"><CheckCheck size={34}/></span><div className="eyebrow">PIETEIKUMS SAŅEMTS</div><h2>Pirmais solis sperts.</h2><p>Paldies! Tavs pieteikums ir saglabāts un pieejams mūsu komandai. Sazināsimies, izmantojot norādīto kontaktinformāciju.</p><p role="status">{confirmation==="pending"?"Apstiprinājuma e-pasts tiek sagatavots. Pārbaudi arī mēstuļu mapi.":confirmation==="sent"?"Apstiprinājuma e-pastu serviss ir pieņēmis nosūtīšanai.":confirmation==="unavailable"?"E-pasta apstiprinājums pašlaik nav pieejams. Tavs pieteikums ir saglabāts; saglabā tā numuru.":"Saglabā pieteikuma numuru turpmākai saziņai."}</p><div className="receipt"><ShieldCheck size={18}/><span>Pieteikuma numurs <strong>{receipt.slice(0,8).toUpperCase()}</strong></span></div><button className="button button-primary" onClick={()=>{setReceipt("");submissionId.current="";}}>Nosūtīt citu pieteikumu</button></div>:<>
          <div className="form-heading"><span className="pill"><Clock3 size={14}/>Aptuveni 2 minūtes</span><h2>Pastāsti par savu uzņēmumu</h2><p>Visi lauki ir obligāti. Atbildi īsi — detaļas izrunāsim sarunā.</p></div>
          <form noValidate onSubmit={submit} className="lead-form">
            <div className="form-row"><label htmlFor="name">Vārds un uzvārds<input {...props("name")} autoComplete="name" maxLength={100} placeholder="Tavs vārds un uzvārds" required/>{fieldError("name")}</label><label htmlFor="phone">Telefons<input {...props("phone")} type="tel" autoComplete="tel" maxLength={40} placeholder="+371 20000000" required/>{fieldError("phone")}</label></div>
            <div className="form-row"><label htmlFor="email">E-pasts<input {...props("email")} type="email" autoComplete="email" maxLength={254} placeholder="vards@uznemums.lv" required/>{fieldError("email")}</label><label htmlFor="company">Uzņēmums<input {...props("company")} autoComplete="organization" maxLength={150} placeholder="Uzņēmuma nosaukums" required/>{fieldError("company")}</label></div>
            <div className="form-row"><label htmlFor="industry">Nozare<select {...props("industry")} defaultValue="" required><option value="" disabled>Izvēlies nozari</option>{INDUSTRIES.map(v=><option key={v}>{v}</option>)}</select>{fieldError("industry")}</label><label htmlFor="revenue">Mēneša apgrozījums<select {...props("revenue")} defaultValue="" required><option value="" disabled>Izvēlies diapazonu</option>{REVENUES.map(v=><option key={v}>{v}</option>)}</select>{fieldError("revenue")}</label></div>
            <label htmlFor="goal">Ko vēlies sasniegt?<textarea {...props("goal")} rows={4} maxLength={2000} placeholder="Piemēram, iegūt vairāk pieteikumu no mājaslapas vai automatizēt klientu apstrādi. Pastāsti arī par termiņu un budžetu, ja tie jau zināmi." required/>{fieldError("goal")}</label>
            <div className="honeypot" aria-hidden="true"><label htmlFor="website">Mājaslapas adrese<input name="website" id="website" autoComplete="off" tabIndex={-1}/></label></div>
            <p className="form-data-notice">Pieteikuma datus izmantosim tā izvērtēšanai un saziņai ar tevi. <a href="/privatums" target="_blank" rel="noreferrer">Par datu izmantošanu</a></p>
            {error&&<div role="alert" className="notice notice-error">{error}</div>}
            <button type="submit" disabled={busy} className="button button-primary submit-button">{busy?<><Spinner/>Saglabā pieteikumu…</>:<>Nosūtīt pieteikumu<MessageSquare size={18}/></>}</button>
            <p className="secure-note"><ShieldCheck size={15}/>Tava informācija ir pieejama tikai pilnvarotai komandai.</p>
          </form>
        </>}
      </section>
    </main>
    <footer className="public-footer"><span>Lead Inbox · Mārcis Sidorčiks</span><a href="/demo">Rīka demonstrācija un statuss</a><a href="/privatums">Datu izmantošana</a></footer>
  </div>;
}

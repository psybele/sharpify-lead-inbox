import { Inbox, LoaderCircle } from "lucide-react";
export function Brand({dark=false}: {dark?:boolean}) {
  return <a href="/" className={`brand ${dark?"brand-light":""}`} aria-label="Lead Inbox sākums"><span className="brand-mark"><Inbox size={23} strokeWidth={2.2}/></span><span>lead<span className="brand-word">inbox</span><span className="brand-period">.</span></span></a>;
}
export function Spinner() { return <LoaderCircle size={18} className="spin" aria-label="Notiek ielāde"/>; }
export class ApiError extends Error {
  status: number; fields?:Record<string,string[]>;
  constructor(message: string,status: number,fields?:Record<string,string[]>) {super(message);this.status=status;this.fields=fields;}
}
export async function api<T=unknown>(path: string,options: RequestInit={}):Promise<T> {
  let response:Response;
  try { response=await fetch(path,{...options,headers:{"Content-Type":"application/json",...options.headers},cache:"no-store"}); }
  catch {throw new ApiError("Nav savienojuma. Pārbaudi internetu un mēģini vēlreiz.",0);}
  let data:{error?:string;fields?:Record<string,string[]>};
  try { data=await response.json() as typeof data; } catch { throw new ApiError("Serveris neatbildēja pareizi. Mēģini vēlreiz.",response.status); }
  if(!response.ok) throw new ApiError(data.error||"Darbība neizdevās.",response.status,data.fields);
  return data as T;
}

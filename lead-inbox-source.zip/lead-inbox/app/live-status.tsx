"use client";
import {useEffect,useState} from "react";
import {CheckCircle2,Clock3,Settings2,RefreshCw,ShieldCheck} from "lucide-react";
import {api,Spinner} from "./components";
import type {PublicStatus} from "../lib/leads-domain";

export function LiveStatus({privacy=false}:{privacy?:boolean}) {
  const [status,setStatus]=useState<PublicStatus|null>(null),[error,setError]=useState(false),[loading,setLoading]=useState(true);
  async function refresh(){setLoading(true);try{setStatus(await api<PublicStatus>("/api/status",{signal:AbortSignal.timeout(18000)}));setError(false);}catch{setError(true);}finally{setLoading(false);}}
  useEffect(()=>{let active=true;const controller=new AbortController();api<PublicStatus>("/api/status",{signal:controller.signal}).then(v=>{if(active){setStatus(v);setError(false);}}).catch(()=>{if(active)setError(true);}).finally(()=>{if(active)setLoading(false);});return()=>{active=false;controller.abort();};},[]);
  const aiConfigured=Boolean(status?.ai.configured),notificationsConfigured=Boolean(status?.notifications.configured);
  const aiProviderName=status?.ai.provider==="groq"?"Groq":"OpenAI";
  const unready=Boolean(status&&(!status.pinConfigured||!aiConfigured||!notificationsConfigured));
  return <section className={`live-status ${privacy?"live-status-privacy":""}`} aria-label="Dzīvās versijas statuss">
    <header className="live-status-heading"><div><span className="eyebrow muted">TIEŠI NO SERVERA</span><h2>Kas šobrīd darbojas?</h2></div><button className="button button-outline button-small" onClick={refresh} disabled={loading} aria-label="Atjaunot savienojumu statusu">{loading?<Spinner/>:<RefreshCw size={15}/>}Atjaunot</button></header>
    {loading&&!status?<div className="status-loading" role="status"><Spinner/>Pārbauda dzīvo konfigurāciju…</div>:error?<div className="notice notice-error" role="alert">Statusu neizdevās nolasīt. Savienojumu darbība šobrīd nav apliecināta.</div>:status?<>
      {unready&&<div className="status-summary"><Settings2 size={20}/><div><strong>Darba versija · savienojumi vēl jāpabeidz</strong><p>{status.pinConfigured?"Forma, datubāze un inbox darbojas.":"Datubāze pieejama, bet formas un inbox piekļuve vēl jāiestata."} {!aiConfigured&&!notificationsConfigured?"AI un ārējie paziņojumi vēl nav pieslēgti.":!aiConfigured?"AI vēl nav pieslēgts.":!notificationsConfigured?"Vēl jāiestata vismaz viens no ieslēgtajiem paziņojumu kanāliem.":""} Pilna pārbaude no formas līdz AI un paziņojumam vēl nav pabeigta.</p></div></div>}
      <div className="status-table-wrap"><table className="status-table"><thead><tr><th>Funkcija</th><th>Pašreizējais stāvoklis</th></tr></thead><tbody>
        <tr><th scope="row">Publiskā forma un datubāze</th><td><span className="live-state ready"><CheckCircle2 size={15}/>Datubāze pieejama</span><p>Pieteikumu saglabā serverī; pārlāde to neizdzēš.</p></td></tr>
        <tr><th scope="row">Pārdevēja inbox un statusi</th><td><span className={`live-state ${status.pinConfigured?"ready":"pending"}`}><ShieldCheck size={15}/>{status.pinConfigured?"PIN piekļuve iestatīta":"PIN nav konfigurēts"}</span><p>Inbox, statusus un piezīmes aizsargā servera sesija.</p></td></tr>
        <tr><th scope="row">AI vērtējums un sarunas sākums</th><td><span className={`live-state ${aiConfigured?"pending":"blocked"}`}><Settings2 size={15}/>{aiConfigured?`${aiProviderName} atslēga saglabāta`:`${aiProviderName} nav pieslēgts`}</span><p>{!aiConfigured?"Datus AI apstrādei nesūta; AI vērtējumu neveido.":status.ai.lastSuccessAt?`Pēdējais veiksmīgais vērtējums: ${formatDate(status.ai.lastSuccessAt)}.`:"Reāls veiksmīgs AI vērtējums vēl nav reģistrēts. Pārbaudi savienojumu inbox iestatījumos."}</p></td></tr>
        {status.notifications.channels.length?status.notifications.channels.map(channel=><tr key={channel.id}><th scope="row">{channelLabel(channel.id)} paziņojumi</th><td><span className={`live-state ${channel.configured?(channel.lastSuccessAt?"ready":"pending"):"blocked"}`}><Settings2 size={15}/>{channel.configured?"Savienojuma dati saglabāti":"Nav pieslēgts"}</span><p>{!channel.configured?"Šim kanālam vēl trūkst pieslēguma datu.":channel.lastSuccessAt?`Serviss pēdējo līda ziņu pieņēma: ${formatDate(channel.lastSuccessAt)}.`:"Reāla līda ziņas pieņemšana šajā kanālā vēl nav reģistrēta."}</p></td></tr>):<tr><th scope="row">Ārējie paziņojumi</th><td><span className="live-state blocked">Nav ieslēgta kanāla</span><p>Iestatījumos var ieslēgt Telegram vai Discord un neatkarīgi arī e-pastu.</p></td></tr>}

      </tbody></table></div>
      <div className="status-checked"><Clock3 size={14}/>Pārbaudīts {formatDate(status.checkedAt)} (Rīgas laiks).</div>
      <p className="status-footnote">Saglabāta atslēga vai kanāls vēl neapliecina piegādi. Pēdējā sekmīgā apstrāde ir vēsturisks ieraksts; tā nepierāda, ka vēlāk mainīti savienojuma dati darbojas.</p>
      {privacy&&<div className="privacy-transmission"><h3>Datu nosūtīšana šajā konfigurācijā</h3><p>{aiConfigured?`${aiProviderName} savienojums ir konfigurēts: pieteikuma uzņēmumu, nozari, apgrozījuma diapazonu un mērķi sūta šim servisam izvērtēšanai. Telefona, vārda un e-pasta laukus šajā pieprasījumā neiekļauj.`:`${aiProviderName} nav pieslēgts. Pieteikuma datus AI apstrādei šobrīd nesūta.`}</p><p>{status.notifications.channels.some(c=>c.configured)?`Pieteikuma kontaktus, uzņēmuma datus un mērķi sūta šajos konfigurētajos kanālos: ${status.notifications.channels.filter(c=>c.configured).map(c=>channelLabel(c.id)).join(", ")}. ${status.notifications.channels.some(c=>c.id==="email"&&c.configured)?" E-pastam izmanto Resend un komandas norādīto saņēmēju.":""}`:"Ārējie kanāli vēl nav pieslēgti. Pieteikumu informāciju Telegram, Discord vai e-pasta servisam pašlaik nesūta."}</p></div>}
    </>:null}
  </section>;
}
function formatDate(timestamp:number){return new Date(timestamp).toLocaleString("lv-LV",{timeZone:"Europe/Riga",day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"});}

function channelLabel(id:string){return id==="email"?"E-pasta (Resend)":id==="telegram"?"Telegram":"Discord";}

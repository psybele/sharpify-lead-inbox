import {mkdirSync,readdirSync,readFileSync,writeFileSync} from "node:fs";
import {spawnSync} from "node:child_process";
// Bootstrap for an empty local database. Production applies each migration once.
mkdirSync(".wrangler",{recursive:true});
const sql=readdirSync("drizzle").filter(f=>f.endsWith(".sql")).sort().map(f=>readFileSync(`drizzle/${f}`,"utf8")).join("\n");
writeFileSync(".wrangler/local-schema.sql",sql);
const result=spawnSync(process.execPath,["--import","./scripts/sites-env.mjs","./node_modules/wrangler/bin/wrangler.js","d1","execute","DB","--local","--config","dist/server/wrangler.json","--persist-to",".wrangler/state","--file",".wrangler/local-schema.sql"],{stdio:"inherit"});
process.exit(result.status??1);

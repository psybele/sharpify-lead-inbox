import {existsSync,writeFileSync} from "node:fs";
import {randomBytes,randomInt,createHash} from "node:crypto";
if(existsSync(".dev.vars")){console.log(".dev.vars jau eksistē. Iestatījumi netika mainīti.");process.exit(0);}
const pin=String(randomInt(100000,1000000)),secret=randomBytes(32).toString("hex");
const pinHash=createHash("sha256").update(`${secret}:${pin}`).digest("hex");
writeFileSync(".dev.vars",`SESSION_SECRET=${secret}\nPIN_HASH=${pinHash}\n`,{mode:0o600});
console.log(`Lokālā vide sagatavota. Tavs lokālais PIN: ${pin}. Saglabā to; tas netiek iekļauts pirmkodā.`);

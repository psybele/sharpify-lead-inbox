"""Package source for code review; exclude credentials, runtime data and builds."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import os

root = Path(__file__).resolve().parent.parent
target = root / "public" / "lead-inbox-source.zip"
excluded = {"node_modules", ".git", ".wrangler", ".sites-runtime", "dist", ".vinext", ".next", "out", "outputs", "work", "coverage", ".agents", ".codex", "__pycache__"}
with ZipFile(target, "w", ZIP_DEFLATED) as archive:
    for folder, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in excluded and not (Path(folder) / d).is_symlink())
        for name in sorted(files):
            path = Path(folder) / name
            relative = path.relative_to(root)
            if path.is_symlink() or path == target or name.startswith((".env", ".dev.vars")) or name.endswith((".tsbuildinfo", ".pem", ".log")):
                continue
            archive.write(path, Path("lead-inbox") / relative)
print(f"Source ZIP created: {target.name} ({target.stat().st_size} bytes)")

import {mkdirSync,copyFileSync} from "node:fs";
import {fileURLToPath} from "node:url";
import {resolve} from "node:path";
const root=fileURLToPath(new URL("../",import.meta.url)),target=resolve(root,"work/vercel-deploy");
for(const folder of ["api","lib"])mkdirSync(resolve(target,folder),{recursive:true});
for(const name of ["package.json","vercel.json","api/bridge.mjs"])copyFileSync(resolve(root,"deploy/vercel",name),resolve(target,name));
for(const name of ["lead-proxy.mjs","vercel-gateway.mjs"])copyFileSync(resolve(root,"lib",name),resolve(target,"lib",name));
console.log(`Vercel gateway packaged: ${target}`);

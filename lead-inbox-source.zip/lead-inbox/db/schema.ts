import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";

export const leads = sqliteTable("leads", {
  id: text("id").primaryKey(),
  submissionId: text("submission_id").notNull().unique(),
  name: text("name").notNull(), phone: text("phone").notNull(), email: text("email").notNull(),
  company: text("company").notNull(), industry: text("industry").notNull(), revenue: text("revenue").notNull(), goal: text("goal").notNull(),
  status: text("status").notNull().default("Jauns"), notes: text("notes").notNull().default(""),
  archivedAt: integer("archived_at"), demoLabel: text("demo_label"),
  aiRating: text("ai_rating"), aiReason: text("ai_reason"), aiOpener: text("ai_opener"),
  aiState: text("ai_state").notNull().default("pending"), aiError: text("ai_error"), aiModel: text("ai_model"), aiCompletedAt: integer("ai_completed_at"),
  notificationState: text("notification_state").notNull().default("pending"), notificationError: text("notification_error"),
  notificationSentAt: integer("notification_sent_at"), notificationMessageId: text("notification_message_id"),
  notificationChannel: text("notification_channel"),
  emailState: text("email_state").notNull().default("disabled"), emailError: text("email_error"),
  emailSentAt: integer("email_sent_at"), emailMessageId: text("email_message_id"),
  customerEmailState: text("customer_email_state").notNull().default("disabled"), customerEmailError: text("customer_email_error"),
  customerEmailSentAt: integer("customer_email_sent_at"), customerEmailMessageId: text("customer_email_message_id"),
  attempts: integer("attempts").notNull().default(0), leaseUntil: integer("lease_until").notNull().default(0),
  createdAt: integer("created_at").notNull(), updatedAt: integer("updated_at").notNull(), consentAt: integer("consent_at").notNull(),
}, table => [index("leads_created_at_idx").on(table.createdAt)]);
export const sessions = sqliteTable("sessions", {
  tokenHash: text("token_hash").primaryKey(), expiresAt: integer("expires_at").notNull(),
});
export const rateLimits = sqliteTable("rate_limits", {
  key: text("key").primaryKey(), hits: integer("hits").notNull(), expiresAt: integer("expires_at").notNull(),
});
export const settings = sqliteTable("settings", {
  id: text("id").primaryKey(), sealed: text("sealed").notNull(), updatedAt: integer("updated_at").notNull(),
});

# Palaišana VS Code uz MacBook

GitHub ir koda glabātuve, VS Code ir redaktors, bet publicētās vietnes hostings jau darbojas atsevišķi. Lai vērtētājs aizpildītu formu, viņam nekas nav jāinstalē.

## Pirmā lokālā palaišana

1. Instalē Node.js 24 LTS un VS Code, ja tie vēl nav datorā.
2. Klonē GitHub repozitoriju vai lejupielādē pilno pirmkoda ZIP no dzīvas vietnes `/kods` lapas un izpako to.
3. VS Code izvēlnē **File → Open Folder…** atver mapi, kurā atrodas `package.json`.
4. Augšējā izvēlnē **Terminal → New Terminal** atver termināli.
5. Secīgi izpildi:

```bash
npm ci
npm run local:setup
npm run build
npm run db:local
npm run dev
```

Ja lieto Git, projekta iegūšanai terminālī:

```bash
git clone https://github.com/psybele/sharpify-lead-inbox.git
cd sharpify-lead-inbox
```

Tad izpildi iepriekš norādītās `npm` komandas šajā mapē.

`local:setup` izvadē parāda jaunu lokālo PIN. Tas atšķiras no publicētā rīka PIN. `.dev.vars` paliek tikai tavā datorā, un Git to ignorē. `db:local` ir paredzēts pirmreizējai tukšas lokālās datubāzes sagatavošanai; neatkārto to datubāzei, kas jau sagatavota.

Atver terminālī parādīto adresi (parasti `http://localhost:5173`). Publiskā forma ir `/`, pārdevēja skats — `/inbox`. Lokālā vide nelasa dzīvos pieteikumus un nesatur dzīvos savienojumus. Ja vajag lokālu AI vai paziņojumu pārbaudi, atslēgas ievadi lokālās lietotnes savienojumos.

Nākamajā reizē pietiek ar:

```bash
npm run dev
```

Serveri aptur ar **Control + C** terminālī.

## Sagatavotie VS Code uzdevumi

Nospied **Command + Shift + P**, izvēlies **Tasks: Run Task** un vajadzīgo uzdevumu:

- **Lead Inbox: first local setup** — secīgi uzstāda atkarības, izveido lokālo PIN, veic build un sagatavo tukšu lokālo datubāzi; izmanto tikai pirmajā reizē.
- **Lead Inbox: dev** — palaiž vietējo serveri.
- **Lead Inbox: check**, **Lead Inbox: test**, **Lead Inbox: build** — pārbaudes un build.

## Ja GitHub repozitorijs vēl jāpublicē pašam

Pilnā pirmkoda ZIP nav Git vēstures. Atverot tā mapi VS Code:

1. Kreisajā malā atver **Source Control** un izvēlies **Initialize Repository**.
2. Pievieno failus, ieraksti commit ziņu, piemēram, `Lead Inbox submission`, un izveido commit.
3. Izvēlies **Publish to GitHub**, pieslēdz savu GitHub kontu un nosauc repozitoriju `sharpify-lead-inbox`.
4. Ja kodu paredzēts dot vērtētājiem ar publisku saiti, izvēlies publisku repozitoriju. Pirms publicēšanas pārliecinies, ka nav pievienoti `.dev.vars`, `.env`, atslēgas, PIN vai privāti pieteikumu dati.

Ja repozitorijs jau ir klonēts, nevajag veidot jaunu: pēc savām koda izmaiņām veic commit un **Sync Changes**. GitHub push pats nepublicē izmaiņas esošajā dzīvajā vietnē.

## Par Vercel, Netlify un Supabase

Šim iesniedzamajam darbam papildu pakalpojumi nav vajadzīgi. Pašreizējais serveris ir Cloudflare Worker ar D1 datubāzes piesaisti, un vietne jau ir publiski pieejama. Pārnešana uz citu izpildvidi ir atsevišķs darbs: jāsaglabā API, autorizācija, datubāze, noslēpumi un fonā apstrādātie paziņojumi. Vienkārši augšupielādējot lapas kā statiskus failus, šīs funkcijas nepārceļas.

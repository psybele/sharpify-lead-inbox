ALTER TABLE `leads` ADD `customer_email_state` text DEFAULT 'disabled' NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `customer_email_error` text;--> statement-breakpoint
ALTER TABLE `leads` ADD `customer_email_sent_at` integer;--> statement-breakpoint
ALTER TABLE `leads` ADD `customer_email_message_id` text;
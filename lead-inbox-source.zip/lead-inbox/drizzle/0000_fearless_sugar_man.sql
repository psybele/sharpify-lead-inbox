CREATE TABLE `leads` (
	`id` text PRIMARY KEY NOT NULL,
	`submission_id` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`email` text NOT NULL,
	`company` text NOT NULL,
	`industry` text NOT NULL,
	`revenue` text NOT NULL,
	`goal` text NOT NULL,
	`status` text DEFAULT 'Jauns' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`ai_rating` text,
	`ai_reason` text,
	`ai_opener` text,
	`ai_state` text DEFAULT 'pending' NOT NULL,
	`ai_error` text,
	`ai_model` text,
	`ai_completed_at` integer,
	`notification_state` text DEFAULT 'pending' NOT NULL,
	`notification_error` text,
	`notification_sent_at` integer,
	`notification_message_id` text,
	`attempts` integer DEFAULT 0 NOT NULL,
	`lease_until` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	`consent_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `leads_submission_id_unique` ON `leads` (`submission_id`);--> statement-breakpoint
CREATE INDEX `leads_created_at_idx` ON `leads` (`created_at`);--> statement-breakpoint
CREATE TABLE `rate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`hits` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` text PRIMARY KEY NOT NULL,
	`sealed` text NOT NULL,
	`updated_at` integer NOT NULL
);

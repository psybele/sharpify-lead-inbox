ALTER TABLE `leads` ADD `archived_at` integer;--> statement-breakpoint
ALTER TABLE `leads` ADD `demo_label` text;
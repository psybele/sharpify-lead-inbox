ALTER TABLE `leads` ADD `notification_channel` text;--> statement-breakpoint
ALTER TABLE `leads` ADD `email_state` text DEFAULT 'disabled' NOT NULL;--> statement-breakpoint
ALTER TABLE `leads` ADD `email_error` text;--> statement-breakpoint
ALTER TABLE `leads` ADD `email_sent_at` integer;--> statement-breakpoint
ALTER TABLE `leads` ADD `email_message_id` text;
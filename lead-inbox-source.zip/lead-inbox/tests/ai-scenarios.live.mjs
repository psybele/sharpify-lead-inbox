// Optional live semantic regression. Creates three marked QA leads, notifies the
// configured sales channels, then marks them inactive. Credentials use hidden stdin.
if(process.stdin.isTTY)process.stdin.setRawMode(true);
process.stdout.write("Ready for live AI scenario JSON (input hidden).\n");
let buffer="";const config=await new Promise(resolve=>process.stdin.on("data",chunk=>{buffer+=chunk.toString();if(buffer.includes("\n")){if(process.stdin.isTTY)process.stdin.setRawMode(false);process.stdin.pause();resolve(JSON.parse(buffer.slice(0,buffer.indexOf("\n"))));}}));
let cookie="";const results=[];
async function call(path,method="GET",data){const response=await fetch(config.origin+path,{method,headers:{"Content-Type":"application/json",...(cookie?{cookie}:{})},...(data===undefined?{}:{body:JSON.stringify(data)}),redirect:"manual",signal:AbortSignal.timeout(22000)});return {status:response.status,headers:response.headers,value:await response.json()};}
const cases=[
  {label:"Tests pie liela apgrozījuma",expected:"Auksts",goal:"Test test test test"},
  {label:"Ticama interese bez termiņa un budžeta",expected:"Silts",goal:"Vēlamies palielināt klientu skaitu mūsu ražošanas uzņēmumam."},
  {label:"Konkrēts mērķis un gatavība sākt",expected:"Karsts",goal:"Vēlamies 30 jaunus kvalificētus klientu pieteikumus mēnesī mūsu ražošanas uzņēmumam. Projektam ir 2000 eiro budžets, vēlamies sākt nākamnedēļ."},
];
let error;
try{
  const login=await call("/api/session","POST",{pin:config.pin});if(login.status!==200)throw Error(`Login failed (${login.status})`);cookie=login.headers.get("set-cookie").split(";")[0];
  const submitted=await Promise.all(cases.map(async sample=>{
    const response=await call("/api/leads","POST",{submissionId:crypto.randomUUID(),name:"QA prioritāšu pārbaude",phone:"+447700900123",email:"qa-rating@example.com",company:"QA vērtēšanas scenārijs",industry:"Ražošana",revenue:"Virs 100 000 €",goal:sample.goal,website:""});
    if(response.status!==201)throw Error(`Submission failed (${response.status})`);
    const item={...sample,id:response.value.id};results.push(item);return item;
  }));
  const deadline=Date.now()+45000;
  while(Date.now()<deadline){
    const list=await call("/api/leads");if(list.status!==200)throw Error(`Inbox read failed (${list.status})`);
    for(const item of submitted){const lead=list.value.leads.find(l=>l.id===item.id);if(lead){item.state=lead.ai_state;item.actual=lead.ai_rating;item.reason=lead.ai_reason;item.opener=lead.ai_opener;item.notificationState=lead.notification_state;item.passed=lead.ai_state==="done"&&lead.ai_rating===item.expected;}}
    if(submitted.every(v=>v.state&&v.state!=="pending"))break;
    await new Promise(resolve=>setTimeout(resolve,1200));
  }
}catch(err){error=err.message;}finally{
  if(cookie){for(const item of results){try{item.markedInactive=(await call(`/api/leads/${item.id}`,"PATCH",{status:"Nav aktuāls",notes:"Automātiska AI prioritāšu pārbaude ar izdomātiem kontaktiem. Nav pārdošanas līds; nezvanīt un nerakstīt."})).status===200;}catch{item.markedInactive=false;}}
    try{await call("/api/session","DELETE");}catch{/* Session still expires automatically. */}
  }
}
process.stdout.write(JSON.stringify({ok:!error&&results.length===cases.length&&results.every(v=>v.passed&&v.markedInactive),error,results})+"\n");

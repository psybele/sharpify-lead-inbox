import test from "node:test";
import assert from "node:assert/strict";
import {signedProxyHeaders,restoreProxyRequest,proxyHeader} from "../lib/lead-proxy.mjs";
import {proxyApi} from "../lib/vercel-gateway.mjs";

const secret="isolated-proxy-test-secret",origin="https://lead-inbox-test.vercel.app";
async function signed(overrides={}){
  const request=new Request("https://backend.test/api/session",{method:"POST",headers:{origin,cookie:`lead_session=${"a".repeat(64)}`,"content-type":"application/json"},body:'{"pin":"123456"}'});
  const signedHeaders=await signedProxyHeaders(request,secret,origin,"198.51.100.10");
  for(const [k,v] of Object.entries(signedHeaders))request.headers.set(k,v);
  return new Request(request,overrides);
}
test("signed proxy context preserves public origin, client IP and body; unsigned requests stay unchanged",async()=>{
  const request=await signed(),restored=await restoreProxyRequest(request,secret);
  assert.equal(restored.url,origin+"/api/session");assert.equal(restored.headers.get("cf-connecting-ip"),"198.51.100.10");assert.equal(await restored.text(),'{"pin":"123456"}');assert.equal(restored.headers.has(proxyHeader),false);
  const direct=new Request("https://backend.test/api/status");assert.equal(await restoreProxyRequest(direct,undefined),direct);
});
test("proxy authentication rejects missing key, expired proof, changed body, cookie and route",async()=>{
  assert.equal(await restoreProxyRequest(await signed(),undefined),null);
  assert.equal(await restoreProxyRequest(await signed(),secret,Date.now()+120000),null);
  assert.equal(await restoreProxyRequest(await signed({body:'{"pin":"999999"}'}),secret),null);
  const cookie=await signed();cookie.headers.set("cookie",`lead_session=${"b".repeat(64)}`);assert.equal(await restoreProxyRequest(cookie,secret),null);
  const route=await signed();assert.equal(await restoreProxyRequest(new Request("https://backend.test/api/settings",route),secret),null);
  const forged=await signed(),context=JSON.parse(forged.headers.get(proxyHeader));context.ip="198.51.100.99";forged.headers.set(proxyHeader,JSON.stringify(context));assert.equal(await restoreProxyRequest(forged,secret),null);
});
test("gateway blocks cross-site writes, arbitrary targets and oversized requests before fetch",async()=>{
  const original=globalThis.fetch;let calls=0;globalThis.fetch=async()=>{calls++;throw new Error("unexpected");};
  try{
    const send=(path,headers={},body='{}')=>proxyApi(new Request(origin+path,{method:"POST",headers:{"content-type":"application/json",...headers},body}),secret);
    assert.equal((await send("/api/bridge?__lead_path=session",{origin:"https://evil.test"})).status,403);
    assert.equal((await send("/api/bridge?__lead_path=session",{"sec-fetch-site":"cross-site"})).status,403);
    assert.equal((await send("/api/bridge?__lead_path=https://evil.test/")).status,404);
    assert.equal((await send("/api/bridge?__lead_path=leads",{},"x".repeat(16001))).status,413);
    assert.equal(calls,0);
  }finally{globalThis.fetch=original;}
});
test("gateway forwards only the app cookie, authenticates client context and preserves secure cookie/no-store",async()=>{
  const original=globalThis.fetch;let captured;
  globalThis.fetch=async request=>{captured=request;return Response.json({ok:true},{headers:{"set-cookie":`lead_session=${"b".repeat(64)}; Path=/; HttpOnly; Secure; SameSite=Strict`,"content-encoding":"gzip"}});};
  try{
    const response=await proxyApi(new Request(origin+"/api/session?__lead_path=session",{method:"POST",headers:{origin,"content-type":"application/json",cookie:`unrelated=private; lead_session=${"a".repeat(64)}`,"x-vercel-forwarded-for":"198.51.100.20","authorization":"do-not-forward"},body:'{"pin":"123456"}'}),secret);
    assert.equal(response.status,200);assert.equal(captured.url,"https://lead-inbox-sharpify.marcis98000.chatgpt.site/api/session");assert.equal(captured.redirect,"manual");assert.equal(captured.headers.get("authorization"),null);assert.equal(captured.headers.get("cookie"),`lead_session=${"a".repeat(64)}`);
    const restored=await restoreProxyRequest(captured,secret);assert.equal(restored.url,origin+"/api/session");assert.equal(restored.headers.get("cf-connecting-ip"),"198.51.100.20");
    assert.equal(response.headers.get("cache-control"),"no-store");assert.equal(response.headers.get("vercel-cdn-cache-control"),"no-store");assert.equal(response.headers.get("content-encoding"),null);assert.match(response.headers.get("set-cookie"),/HttpOnly; Secure; SameSite=Strict/);
  }finally{globalThis.fetch=original;}
});
test("gateway does not follow upstream redirects or expose transport errors",async()=>{
  const original=globalThis.fetch;
  try{
    globalThis.fetch=async()=>new Response(null,{status:302,headers:{location:"https://evil.test"}});
    assert.equal((await proxyApi(new Request(origin+"/api/bridge?__lead_path=status"),secret)).status,502);
    globalThis.fetch=async()=>{throw new Error("secret-from-transport");};const response=await proxyApi(new Request(origin+"/api/bridge?__lead_path=status"),secret);assert.equal(response.status,502);assert.ok(!(await response.text()).includes("secret-from-transport"));
  }finally{globalThis.fetch=original;}
});

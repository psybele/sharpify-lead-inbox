// Reads test configuration from hidden stdin. Never prints credentials/cookies.
import assert from "node:assert/strict";
if(process.stdin.isTTY)process.stdin.setRawMode(true);
process.stdout.write("Ready for live QA JSON on stdin (input is hidden).\n");
let buffer="";
const config=await new Promise(resolve=>process.stdin.on("data",chunk=>{buffer+=chunk.toString();const end=buffer.indexOf("\n");if(end>=0){if(process.stdin.isTTY)process.stdin.setRawMode(false);process.stdin.pause();resolve(JSON.parse(buffer.slice(0,end)));}}));
const {origin,pin}=config;
async function request(path,method="GET",data,extra={}){
  return fetch(origin+path,{method,headers:{"Content-Type":"application/json",...extra},...(data===undefined?{}:{body:JSON.stringify(data)}),redirect:"manual",signal:AbortSignal.timeout(25000)});
}
const checks=[];
assert.equal((await request("/api/leads")).status,401);checks.push("unauthenticated lead access denied");
assert.equal((await request("/api/settings")).status,401);checks.push("unauthenticated settings denied");
assert.equal((await request(`/api/leads/${crypto.randomUUID()}`,"PATCH",{status:"Piezvanīts"})).status,401);checks.push("unauthenticated status mutation denied");
assert.equal((await request("/api/settings","POST",{})).status,401);checks.push("unauthenticated configuration mutation denied");
assert.equal((await request("/api/leads","GET",undefined,{cookie:`lead_session=${"a".repeat(64)}`})).status,401);checks.push("forged session denied");
assert.equal((await request("/api/session","POST",{pin:"000000"})).status,401);checks.push("wrong PIN denied");
const logged=await request("/api/session","POST",{pin});assert.equal(logged.status,200);
const setCookie=logged.headers.get("set-cookie"),cookie=setCookie?.split(";")[0];assert.ok(cookie);for(const flag of ["HttpOnly","Secure","SameSite=Strict"])assert.ok(setCookie.includes(flag));checks.push("PIN login and secure session");
const publicStatusResponse=await request("/api/status");assert.equal(publicStatusResponse.status,200);const publicStatus=await publicStatusResponse.json();assert.equal(publicStatus.database,"available");assert.equal(publicStatus.pinConfigured,true);assert.equal(publicStatus.leads,undefined);assert.equal(publicStatus.aiKey,undefined);checks.push("public runtime status has no lead data or credentials");
const payload={submissionId:crypto.randomUUID(),name:"QA Release",phone:"+37120000000",email:"release-qa@example.com",company:"QA · Nodošanas uzlabojumu pārbaude",industry:"Pakalpojumi",revenue:"5 000–10 000 €",goal:"Tehnisks publicētās versijas QA tests. Pārbaudām datu saglabāšanu un statusa maiņu. Nav nepieciešama saziņa.",website:""};
assert.equal((await request("/api/leads","POST",{...payload,email:"invalid"})).status,422);checks.push("invalid form rejected");
assert.equal((await request("/api/leads","POST",payload,{Origin:"https://unrelated.example"})).status,403);checks.push("cross-origin writes denied");
const started=Date.now(),posted=await request("/api/leads","POST",payload);assert.equal(posted.status,201);const {id}=await posted.json();
let list=await(await request("/api/leads","GET",undefined,{cookie})).json();assert.ok(list.leads.some(l=>l.id===id));const appearedMs=Date.now()-started;checks.push("public submission appears in protected inbox");
assert.equal(list.leads.find(l=>l.id===id).consent_at,0);checks.push("no checkbox required; no invented consent recorded");
assert.equal((await(await request("/api/leads","POST",payload)).json()).id,id);checks.push("duplicate retry stays one lead");
const updated=await request(`/api/leads/${id}`,"PATCH",{status:"Nav aktuāls",notes:"QA tests pabeigts. Nav nepieciešama saziņa."},{cookie});assert.equal(updated.status,200);
list=await(await request("/api/leads","GET",undefined,{cookie})).json();const saved=list.leads.find(l=>l.id===id);assert.equal(saved.status,"Nav aktuāls");assert.equal(saved.notes,"QA tests pabeigts. Nav nepieciešama saziņa.");checks.push("status and notes persist across requests");
const settings=await(await request("/api/settings","GET",undefined,{cookie})).json();assert.equal(settings.aiKey,undefined);assert.equal(settings.telegramToken,undefined);assert.equal(settings.resendKey,undefined);assert.equal(typeof settings.emailEnabled,"boolean");assert.equal(typeof saved.email_state,"string");checks.push("settings never expose credentials");
const logout=await request("/api/session","DELETE",undefined,{cookie});assert.equal(logout.status,200);assert.equal((await request("/api/leads","GET",undefined,{cookie})).status,401);checks.push("logout revokes session");
process.stdout.write(JSON.stringify({ok:true,checks,leadId:id,inboxAppearedMs:appearedMs,integrations:list.integrations,externalPipelineVerified:false})+"\n");

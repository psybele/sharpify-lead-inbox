import test from "node:test";
import assert from "node:assert/strict";
import {DatabaseSync} from "node:sqlite";
import {readFileSync,readdirSync} from "node:fs";
import {handleApi,hash,seal,unseal,processLead,evaluate,notify,getIntegrations} from "../lib/leads-server.ts";
import {normalizePhone,telephoneLink,aiOutput} from "../lib/leads-domain.ts";
import {signedProxyHeaders,proxyHeader} from "../lib/lead-proxy.mjs";

const migrationDir=new URL("../drizzle/",import.meta.url);
const migration=readdirSync(migrationDir).filter(f=>f.endsWith(".sql")).sort().map(f=>readFileSync(new URL(f,migrationDir),"utf8")).join("\n");
const origin="https://lead-inbox.test",pin="854712";
function fakeD1(sqlite){return {prepare(sql){let args=[];return {bind(...values){args=values;return this;},async first(){return sqlite.prepare(sql).get(...args)||null;},async all(){return {results:sqlite.prepare(sql).all(...args),success:true};},async run(){const result=sqlite.prepare(sql).run(...args);return {success:true,meta:{changes:result.changes}};}};},async batch(statements){return Promise.all(statements.map(s=>s.run()));}};}
async function setup(extra={}){
  const sqlite=new DatabaseSync(":memory:");sqlite.exec(migration);
  const env={DB:fakeD1(sqlite),SESSION_SECRET:"test-session-secret-for-unit-tests-only",...extra};
  env.PIN_HASH=await hash(`${env.SESSION_SECRET}:${pin}`);
  const tasks=[],ctx={waitUntil(task){tasks.push(task);}};
  async function call(path,method="GET",data,headers={}){return handleApi(new Request(origin+path,{method,headers:{"content-type":"application/json",...headers},...(data===undefined?{}:{body:JSON.stringify(data)})}),env,ctx);}
  async function login(){const response=await call("/api/session","POST",{pin});assert.equal(response.status,200);return response.headers.get("set-cookie").split(";")[0];}
  async function settle(){while(tasks.length)await Promise.all(tasks.splice(0));}
  return {sqlite,env,ctx,call,login,settle};
}
function input(overrides={}){return {submissionId:crypto.randomUUID(),name:"Testa Klients",phone:"2000 0000",email:"TEST@example.com",company:"Testa uzņēmums",industry:"Pakalpojumi",revenue:"10 000–50 000 €",goal:"Vēlamies palielināt pieteikumu skaitu nākamajā mēnesī.",consent:true,website:"",...overrides};}
function aiResponse(){return Response.json({output:[{content:[{type:"output_text",text:JSON.stringify({rating:"Silts",reason:"Ir konkrēta vēlme palielināt pieteikumus, bet budžets vēl nav norādīts.",opener:"Kādu pieteikumu pieaugumu vēlaties sasniegt nākamajā mēnesī?"})}]}]});}
const configured={OPENAI_API_KEY:"sk-test-secret",TELEGRAM_BOT_TOKEN:"123456:fake-token",TELEGRAM_CHAT_ID:"1234"};

test("Vercel proxy keeps per-client PIN limits and rejects forged context",async()=>{
  const s=await setup({LEAD_PROXY_SECRET:"unit-test-proxy-secret"}),publicOrigin="https://lead-inbox-test.vercel.app";
  async function proxied(ip,pinValue){const request=new Request(origin+"/api/session",{method:"POST",headers:{origin:publicOrigin,"content-type":"application/json","cf-connecting-ip":"203.0.113.5"},body:JSON.stringify({pin:pinValue})});for(const [key,value]of Object.entries(await signedProxyHeaders(request,s.env.LEAD_PROXY_SECRET,publicOrigin,ip)))request.headers.set(key,value);return handleApi(request,s.env,s.ctx);}
  for(let n=0;n<8;n++)assert.equal((await proxied("198.51.100.10","000000")).status,401);
  assert.equal((await proxied("198.51.100.10",pin)).status,429);assert.equal((await proxied("198.51.100.11",pin)).status,200);
  assert.equal((await s.call("/api/status","GET",undefined,{[proxyHeader]:"forged"})).status,403);
});

test("Vercel submission stores the lead and uses the public Vercel inbox in notifications",async()=>{
  const s=await setup({...configured,LEAD_PROXY_SECRET:"unit-test-proxy-secret"}),publicOrigin="https://lead-inbox-test.vercel.app",original=globalThis.fetch;let notification;
  globalThis.fetch=async(url,options)=>{if(String(url).includes("openai.com"))return aiResponse();notification=JSON.parse(options.body).text;return Response.json({ok:true,result:{message_id:108}});};
  try{const request=new Request(origin+"/api/leads",{method:"POST",headers:{origin:publicOrigin,"content-type":"application/json"},body:JSON.stringify(input())});for(const [key,value]of Object.entries(await signedProxyHeaders(request,s.env.LEAD_PROXY_SECRET,publicOrigin,"198.51.100.12")))request.headers.set(key,value);const response=await handleApi(request,s.env,s.ctx);assert.equal(response.status,201);const {id}=await response.json();await s.settle();assert.ok(notification.includes(`${publicOrigin}/inbox?lead=${id}`));assert.equal(s.sqlite.prepare("SELECT notification_state FROM leads WHERE id=?").get(id).notification_state,"sent");}finally{globalThis.fetch=original;}
});

test("normalizes local and international telephone numbers",()=>{assert.equal(normalizePhone("20 000 000"),"+37120000000");assert.equal(normalizePhone("00371 (20) 000-000"),"+37120000000");assert.equal(normalizePhone("+44 7700 900123"),"+447700900123");});
test("PIN protects all reads, updates and configuration",async()=>{const s=await setup();for(const [path,method,data] of [["/api/leads","GET"],["/api/settings","GET"],[`/api/leads/${crypto.randomUUID()}`,"PATCH",{status:"Piezvanīts"}],["/api/settings/test","POST",{target:"ai"}]])assert.equal((await s.call(path,method,data)).status,401);});
test("rejects cross-origin writes and malformed payloads",async()=>{const s=await setup();assert.equal((await s.call("/api/leads","POST",input(),{origin:"https://evil.example"})).status,403);const response=await s.call("/api/leads","POST",input({email:"invalid",phone:"123"}));assert.equal(response.status,422);const data=await response.json();assert.ok(data.fields.email);assert.ok(data.fields.phone);assert.equal(s.sqlite.prepare("SELECT COUNT(*) count FROM leads").get().count,0);});
test("honeypot is rejected without creating a lead",async()=>{const s=await setup();assert.equal((await s.call("/api/leads","POST",input({website:"spam.example"}))).status,422);assert.equal(s.sqlite.prepare("SELECT COUNT(*) count FROM leads").get().count,0);});
test("public submission persists and safely handles duplicate retries",async()=>{const s=await setup(),payload=input();const first=await s.call("/api/leads","POST",payload);assert.equal(first.status,201);const {id}=await first.json();await s.settle();const retry=await s.call("/api/leads","POST",payload);assert.equal((await retry.json()).id,id);assert.equal(s.sqlite.prepare("SELECT COUNT(*) count FROM leads").get().count,1);const cookie=await s.login();const response=await s.call("/api/leads","GET",undefined,{cookie});const {leads}=await response.json();assert.equal(leads[0].phone,"+37120000000");assert.equal(leads[0].email,"test@example.com");assert.equal(leads[0].status,"Jauns");assert.equal(leads[0].ai_rating,null);assert.equal(leads[0].ai_state,"blocked");assert.equal(leads[0].notification_state,"blocked");await s.settle();});
test("status and notes survive separate authenticated requests",async()=>{const s=await setup();const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();const cookie=await s.login();assert.equal((await s.call(`/api/leads/${id}`,"PATCH",{status:"Tikšanās norunāta",notes:"Tikšanās otrdien 11.00"},{cookie})).status,200);assert.equal((await s.call(`/api/leads/${id}`,"PATCH",{status:"Nederīgs"},{cookie})).status,422);const data=await(await s.call("/api/leads","GET",undefined,{cookie})).json();assert.equal(data.leads[0].status,"Tikšanās norunāta");assert.equal(data.leads[0].notes,"Tikšanās otrdien 11.00");await s.settle();});
test("session uses secure HTTP-only cookie, expires, and revokes on logout",async()=>{const s=await setup();const response=await s.call("/api/session","POST",{pin});const setCookie=response.headers.get("set-cookie");for(const flag of ["HttpOnly","Secure","SameSite=Strict"])assert.ok(setCookie.includes(flag));const cookie=setCookie.split(";")[0];assert.equal((await s.call("/api/leads","GET",undefined,{cookie})).status,200);await s.settle();assert.equal((await s.call("/api/session","DELETE",undefined,{cookie})).status,200);assert.equal((await s.call("/api/leads","GET",undefined,{cookie})).status,401);const cookie2=await s.login();s.sqlite.exec("UPDATE sessions SET expires_at=0");assert.equal((await s.call("/api/leads","GET",undefined,{cookie:cookie2})).status,401);});
test("PIN brute-force limit returns retry guidance and isolates different client IPs",async()=>{const s=await setup();for(let i=0;i<8;i++)assert.equal((await s.call("/api/session","POST",{pin:"000000"})).status,401);const blocked=await s.call("/api/session","POST",{pin});assert.equal(blocked.status,429);assert.ok(Number(blocked.headers.get("Retry-After"))>0);assert.ok(Number(blocked.headers.get("Retry-After"))<=900);assert.equal((await s.call("/api/session","POST",{pin},{"cf-connecting-ip":"198.51.100.20"})).status,200);});
test("submission burst is rate limited",async()=>{const s=await setup();for(let i=0;i<8;i++){assert.equal((await s.call("/api/leads","POST",input())).status,201);await s.settle();}assert.equal((await s.call("/api/leads","POST",input())).status,429);});
test("AI and Telegram pipeline contracts work with mocked providers",async()=>{const s=await setup(configured),original=globalThis.fetch,calls=[];globalThis.fetch=async(url,options)=>{calls.push({url,body:JSON.parse(options.body)});return String(url).includes("openai.com")?aiResponse():Response.json({ok:true,result:{message_id:42}});};try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.ai_rating,"Silts");assert.equal(lead.ai_state,"done");assert.equal(lead.notification_state,"sent");assert.equal(lead.notification_message_id,"42");assert.ok(lead.notification_sent_at-lead.created_at<60000);const modelInput=JSON.parse(calls[0].body.input);assert.deepEqual(Object.keys(modelInput).sort(),["company","goal","industry","monthlyRevenue"]);assert.equal(calls[0].body.store,false);assert.equal(calls[0].body.text.format.strict,true);assert.ok(calls[1].body.text.includes("+37120000000"));assert.ok(calls[1].body.text.includes(`/inbox?lead=${id}`));}finally{globalThis.fetch=original;}});
test("AI errors retain lead and still deliver the notification",async()=>{const s=await setup(configured),original=globalThis.fetch;globalThis.fetch=async url=>String(url).includes("openai.com")?new Response("Unauthorized",{status:401}):Response.json({ok:true,result:{message_id:43}});try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.ai_state,"failed");assert.equal(lead.ai_rating,null);assert.ok(lead.ai_error.includes("401"));assert.equal(lead.notification_state,"sent");assert.equal(lead.lease_until,0);}finally{globalThis.fetch=original;}});
test("retry only repeats failed phases; leases prevent duplicate concurrent work",async()=>{const s=await setup(configured),original=globalThis.fetch;let aiCalls=0,notifications=0,fail=true;globalThis.fetch=async url=>{if(String(url).includes("openai.com")){aiCalls++;return aiResponse();}notifications++;return fail?new Response("Unavailable",{status:503}):Response.json({ok:true,result:{message_id:44}});};try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();assert.equal(s.sqlite.prepare("SELECT notification_state FROM leads WHERE id=?").get(id).notification_state,"failed");fail=false;await Promise.all([processLead(id,s.env,origin),processLead(id,s.env,origin)]);assert.equal(aiCalls,1);assert.equal(notifications,2);assert.equal(s.sqlite.prepare("SELECT notification_state FROM leads WHERE id=?").get(id).notification_state,"sent");}finally{globalThis.fetch=original;}});
test("integration secrets stay encrypted and unsupported notification providers are rejected",async()=>{const s=await setup(),cookie=await s.login(),settings={aiKey:"sk-test-secret-value",aiModel:"gpt-4.1-mini",notificationProvider:"telegram",telegramChatId:"1234",telegramToken:"123456:secret-token"};assert.equal((await s.call("/api/settings","POST",settings,{cookie})).status,200);const sealed=s.sqlite.prepare("SELECT sealed FROM settings").get().sealed;assert.ok(!sealed.includes("sk-test"));assert.ok(!sealed.includes("secret-token"));const response=await(await s.call("/api/settings","GET",undefined,{cookie})).text();assert.ok(!response.includes("secret-value"));assert.ok(!response.includes("secret-token"));assert.ok(response.includes('"hasAiKey":true'));assert.equal((await s.call("/api/settings","POST",{...settings,notificationProvider:"unsupported"},{cookie})).status,422);});
test("encrypted settings reject tampering",async()=>{const s=await setup(),cipher=await seal({secret:"private"},s.env);assert.equal((await unseal(cipher,s.env)).secret,"private");await assert.rejects(()=>unseal(cipher,{...s.env,SESSION_SECRET:"different"}));});
test("invalid model output cannot be saved as a valid rating",()=>{assert.equal(aiOutput.safeParse({rating:"Hot",reason:"Valid explanation here",opener:"Valid opener here"}).success,false);assert.equal(aiOutput.safeParse({rating:"Karsts",reason:"short",opener:"Valid opener here"}).success,false);});
test("all seven assignment data fields remain required",async()=>{const s=await setup();for(const field of ["name","phone","email","company","industry","revenue","goal"]){const payload=input();delete payload[field];const response=await s.call("/api/leads","POST",payload);assert.equal(response.status,422,field);}assert.equal(s.sqlite.prepare("SELECT COUNT(*) count FROM leads").get().count,0);});
test("submission needs no extra checkbox and does not record invented consent",async()=>{const s=await setup(),payload=input();delete payload.consent;const response=await s.call("/api/leads","POST",payload);assert.equal(response.status,201);const {id}=await response.json();await s.settle();const lead=s.sqlite.prepare("SELECT consent_at FROM leads WHERE id=?").get(id);assert.equal(lead.consent_at,0);});
test("forged session cookies cannot read or change private data",async()=>{const s=await setup(),cookie=`lead_session=${"a".repeat(64)}`;for(const [path,method,data] of [["/api/leads","GET"],["/api/settings","GET"],[`/api/leads/${crypto.randomUUID()}`,"PATCH",{status:"Piezvanīts"}],["/api/settings","POST",{}]])assert.equal((await s.call(path,method,data,{cookie})).status,401);});
test("public status reports real configuration without leads or secrets",async()=>{const s=await setup();await s.call("/api/leads","POST",input({name:"Private contact",company:"Private company"}));await s.settle();const response=await s.call("/api/status");assert.equal(response.status,200);assert.equal(response.headers.get("cache-control"),"no-store");const text=await response.text(),data=JSON.parse(text);assert.equal(data.database,"available");assert.equal(data.pinConfigured,true);assert.deepEqual(data.ai,{configured:false,provider:"openai",model:"gpt-4.1-mini",lastSuccessAt:null});assert.equal(data.notifications.configured,false);for(const forbidden of ["Private contact","Private company","+37120000000","test@example.com",s.env.SESSION_SECRET,s.env.PIN_HASH])assert.ok(!text.includes(forbidden));});
test("saved keys are distinguished from verified real provider success",async()=>{const s=await setup(configured);const response=await s.call("/api/status"),data=await response.json();assert.equal(data.ai.configured,true);assert.equal(data.ai.lastSuccessAt,null);assert.equal(data.notifications.configured,true);assert.equal(data.notifications.lastSuccessAt,null);assert.ok(!JSON.stringify(data).includes(configured.OPENAI_API_KEY));});

test("phone actions only produce canonical telephone URIs",()=>{
  assert.equal(telephoneLink("20 000 000"),"tel:+37120000000");
  assert.equal(telephoneLink("00371 (20) 000-000"),"tel:+37120000000");
  for(const value of ["javascript:alert(1)","/call/+37120000000","tel:+37120000000","123","+00123456789","+37120000000;ext=1"])assert.equal(telephoneLink(value),null,value);
});
const mailSettings={aiModel:"gpt-4.1-mini",notificationProvider:"telegram",telegramChatId:"1234",messengerEnabled:false,emailEnabled:true,customerEmailEnabled:false,resendKey:"re_test-secret-key",emailFrom:"lidi@example.org",emailTo:"seller@example.org"};
test("customer receipt is separate, private, idempotent and visible without exposing the recipient publicly",async()=>{
  const s=await setup(),cookie=await s.login(),original=globalThis.fetch,calls=[];
  await s.call("/api/settings","POST",{...mailSettings,customerEmailEnabled:true},{cookie});
  globalThis.fetch=async(url,options)=>{calls.push({body:JSON.parse(options.body),key:options.headers["Idempotency-Key"]});return Response.json({id:`mail-${calls.length}`});};
  try{
    const payload=input({email:"client@example.com",goal:"Private commercial goal and budget not for email.",name:"<script>private name</script>"});
    const submitted=await s.call("/api/leads","POST",payload),result=await submitted.json();assert.equal(result.confirmation,"pending");await s.settle();
    const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(result.id);assert.equal(lead.customer_email_state,"sent");assert.ok(lead.customer_email_message_id);assert.equal(lead.email_state,"sent");
    const client=calls.find(c=>c.body.to[0]===payload.email),seller=calls.find(c=>c.body.to[0]===mailSettings.emailTo);assert.ok(client);assert.ok(seller);assert.equal(client.body.reply_to,mailSettings.emailTo);assert.ok(client.body.text.includes(result.id.slice(0,8).toUpperCase()));assert.ok(client.body.html.includes('lang="lv"'));
    for(const forbidden of [payload.goal,payload.name,"/inbox","PIN","Silts","Auksts","Karsts"])assert.ok(!JSON.stringify(client.body).includes(forbidden),forbidden);
    assert.notEqual(client.key,seller.key);await s.call("/api/leads","POST",payload);await s.call(`/api/leads/${result.id}/retry`,"POST",{},{cookie});await s.settle();assert.equal(calls.length,2);
    const status=await(await s.call("/api/status")).json();assert.equal(status.customerConfirmation.lastSuccessAt,lead.customer_email_sent_at);assert.equal(status.customerConfirmation.configured,true);assert.ok(!JSON.stringify(status).includes(payload.email));
  }finally{globalThis.fetch=original;}
});
test("customer confirmation starts before slow AI and survives AI failure",async()=>{
  const s=await setup(configured),cookie=await s.login(),original=globalThis.fetch;
  await s.call("/api/settings","POST",{...mailSettings,customerEmailEnabled:true,emailEnabled:false,messengerEnabled:true},{cookie});
  let releaseAi,receiptSeen;const aiGate=new Promise(resolve=>{releaseAi=resolve;}),receiptGate=new Promise(resolve=>{receiptSeen=resolve;});
  globalThis.fetch=async(url,options)=>{if(String(url).includes("openai.com")){await aiGate;return new Response("Unavailable",{status:503});}if(String(url).includes("telegram.org"))return Response.json({ok:true,result:{message_id:501}});receiptSeen();return Response.json({id:"client-before-ai"});};
  try{const {id}=await(await s.call("/api/leads","POST",input())).json();await receiptGate;assert.equal(s.sqlite.prepare("SELECT ai_state FROM leads WHERE id=?").get(id).ai_state,"pending");releaseAi();await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.customer_email_state,"sent");assert.equal(lead.ai_state,"failed");assert.equal(lead.notification_state,"sent");}finally{releaseAi();await s.settle();globalThis.fetch=original;}
});
test("Resend test sender blocks customer addresses without affecting seller delivery",async()=>{
  const s=await setup(),cookie=await s.login(),original=globalThis.fetch,calls=[];
  await s.call("/api/settings","POST",{...mailSettings,customerEmailEnabled:true,emailFrom:"onboarding@resend.dev"},{cookie});
  globalThis.fetch=async(url,options)=>{calls.push(JSON.parse(options.body));return Response.json({id:"seller-only"});};
  try{const response=await(await s.call("/api/leads","POST",input())).json();assert.equal(response.confirmation,"unavailable");await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(response.id);assert.equal(lead.customer_email_state,"blocked");assert.match(lead.customer_email_error,/domēnu/);assert.equal(lead.email_state,"sent");assert.equal(calls.length,1);assert.deepEqual(calls[0].to,[mailSettings.emailTo]);const status=await(await s.call("/api/status")).json();assert.equal(status.customerConfirmation.testSender,true);assert.equal(status.customerConfirmation.configured,false);}finally{globalThis.fetch=original;}
});
test("customer confirmation retries only its failed phase with stable idempotency",async()=>{
  const s=await setup(),cookie=await s.login(),original=globalThis.fetch,keys=[];let fail=true,sellerCalls=0;
  await s.call("/api/settings","POST",{...mailSettings,customerEmailEnabled:true},{cookie});
  globalThis.fetch=async(url,options)=>{const value=JSON.parse(options.body);if(value.to[0]===mailSettings.emailTo){sellerCalls++;return Response.json({id:"seller-ok"});}keys.push(options.headers["Idempotency-Key"]);return fail?new Response("Unavailable",{status:503}):Response.json({id:"client-ok"});};
  try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();assert.equal(s.sqlite.prepare("SELECT customer_email_state FROM leads WHERE id=?").get(id).customer_email_state,"failed");fail=false;await s.call(`/api/leads/${id}/retry`,"POST",{},{cookie});await s.settle();assert.equal(s.sqlite.prepare("SELECT customer_email_state FROM leads WHERE id=?").get(id).customer_email_state,"sent");assert.equal(sellerCalls,1);assert.equal(keys.length,2);assert.equal(keys[0],keys[1]);}finally{globalThis.fetch=original;}
});
test("enabling confirmations never sends historical or disabled confirmations, even on retry",async()=>{
  const s=await setup(),cookie=await s.login(),original=globalThis.fetch;
  await s.call("/api/settings","POST",{...mailSettings,emailEnabled:false},{cookie});const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();
  await s.call("/api/settings","POST",{...mailSettings,emailEnabled:false,customerEmailEnabled:true},{cookie});let calls=0;globalThis.fetch=async()=>{calls++;return Response.json({id:"unexpected"});};
  try{await s.call(`/api/leads/${id}/retry`,"POST",{},{cookie});await s.settle();assert.equal(calls,0);assert.equal(s.sqlite.prepare("SELECT customer_email_state FROM leads WHERE id=?").get(id).customer_email_state,"disabled");}finally{globalThis.fetch=original;}
});
test("recipient confirmation limit retains all leads and caps email abuse across IPs",async()=>{
  const s=await setup(),cookie=await s.login(),original=globalThis.fetch;await s.call("/api/settings","POST",{...mailSettings,emailEnabled:false,customerEmailEnabled:true},{cookie});let calls=0;globalThis.fetch=async()=>{calls++;return Response.json({id:`receipt-${calls}`});};
  try{const ids=[];for(let i=0;i<4;i++){const response=await s.call("/api/leads","POST",input(),{"cf-connecting-ip":`198.51.100.${i+1}`});assert.equal(response.status,201);ids.push((await response.json()).id);await s.settle();}assert.equal(calls,3);assert.equal(s.sqlite.prepare("SELECT COUNT(*) count FROM leads").get().count,4);const blocked=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(ids[3]);assert.equal(blocked.customer_email_state,"blocked");assert.match(blocked.customer_email_error,/limits/);}finally{globalThis.fetch=original;}
});
test("email-only setup sends to the configured seller and redacts credentials",async()=>{
  const s=await setup(),cookie=await s.login(),original=globalThis.fetch,calls=[];
  assert.equal((await s.call("/api/settings","POST",mailSettings,{cookie})).status,200);
  const publicStatus=await(await s.call("/api/status")).json();assert.equal(publicStatus.notifications.configured,true);assert.deepEqual(publicStatus.notifications.channels,[{id:"email",configured:true,lastSuccessAt:null}]);
  const settingsText=await(await s.call("/api/settings","GET",undefined,{cookie})).text();assert.ok(!settingsText.includes(mailSettings.resendKey));assert.equal(JSON.parse(settingsText).hasResendKey,true);
  const sealed=s.sqlite.prepare("SELECT sealed FROM settings").get().sealed;assert.ok(!sealed.includes(mailSettings.resendKey));assert.ok(!sealed.includes(mailSettings.emailTo));
  globalThis.fetch=async(url,options)=>{calls.push({url:String(url),options,body:JSON.parse(options.body)});return Response.json({id:"email-accepted-123"});};
  try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.notification_state,"disabled");assert.equal(lead.email_state,"sent");assert.equal(lead.email_message_id,"email-accepted-123");assert.equal(calls.length,1);assert.equal(calls[0].url,"https://api.resend.com/emails");assert.deepEqual(calls[0].body.to,[mailSettings.emailTo]);assert.equal(calls[0].body.from,mailSettings.emailFrom);assert.ok(calls[0].body.text.includes(`/inbox?lead=${id}`));assert.ok(calls[0].options.headers["Idempotency-Key"].includes(id));const statusText=await(await s.call("/api/status")).text();assert.ok(!statusText.includes(mailSettings.emailTo));assert.equal(JSON.parse(statusText).notifications.channels[0].lastSuccessAt,lead.email_sent_at);}finally{globalThis.fetch=original;}
});
test("Telegram success survives email failure and retries only email",async()=>{
  const s=await setup(configured),cookie=await s.login(),original=globalThis.fetch;
  await s.call("/api/settings","POST",{...mailSettings,messengerEnabled:true},{cookie});
  let aiCalls=0,telegramCalls=0,emailCalls=0,fail=true;const keys=[];
  globalThis.fetch=async(url,options)=>{if(String(url).includes("openai.com")){aiCalls++;return aiResponse();}if(String(url).includes("telegram.org")){telegramCalls++;return Response.json({ok:true,result:{message_id:88}});}emailCalls++;keys.push(options.headers["Idempotency-Key"]);return fail?new Response("Unverified sender",{status:403}):Response.json({id:"resend-89"});};
  try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();let lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.ai_state,"done");assert.equal(lead.notification_state,"sent");assert.equal(lead.notification_channel,"telegram");assert.equal(lead.email_state,"failed");assert.ok(lead.email_error.includes("403"));fail=false;await s.call(`/api/leads/${id}/retry`,"POST",{},{cookie});await s.settle();lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.email_state,"sent");assert.equal(aiCalls,1);assert.equal(telegramCalls,1);assert.equal(emailCalls,2);assert.equal(keys[0],keys[1]);}finally{globalThis.fetch=original;}
});
test("email succeeds even when Telegram fails; disabling both does not report ready",async()=>{
  const s=await setup(configured),cookie=await s.login(),original=globalThis.fetch;
  await s.call("/api/settings","POST",{...mailSettings,messengerEnabled:true},{cookie});
  globalThis.fetch=async url=>String(url).includes("openai.com")?aiResponse():String(url).includes("telegram.org")?new Response("Forbidden",{status:403}):Response.json({id:"email-ok"});
  try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.notification_state,"failed");assert.equal(lead.email_state,"sent");await s.call("/api/settings","POST",{...mailSettings,messengerEnabled:false,emailEnabled:false},{cookie});const status=await(await s.call("/api/status")).json();assert.equal(status.notifications.configured,false);assert.deepEqual(status.notifications.channels,[]);}finally{globalThis.fetch=original;}
});
test("incomplete enabled email channel blocks overall readiness and cannot send a test",async()=>{
  const s=await setup(),cookie=await s.login();await s.call("/api/settings","POST",{...mailSettings,messengerEnabled:true,emailTo:"",telegramToken:configured.TELEGRAM_BOT_TOKEN},{cookie});
  const config=await(await s.call("/api/settings","GET",undefined,{cookie})).json();assert.equal(config.messengerReady,true);assert.equal(config.emailReady,false);assert.equal(config.notifications,false);assert.equal((await s.call("/api/settings/test","POST",{target:"email"},{cookie})).status,422);
  const original=globalThis.fetch;globalThis.fetch=async()=>Response.json({ok:true,result:{message_id:99}});try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();assert.equal(s.sqlite.prepare("SELECT email_state FROM leads WHERE id=?").get(id).email_state,"blocked");}finally{globalThis.fetch=original;}
});
test("historical leads do not receive email just because email is enabled",async()=>{
  const s=await setup(),cookie=await s.login();const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();assert.equal(s.sqlite.prepare("SELECT email_state FROM leads WHERE id=?").get(id).email_state,"disabled");
  await s.call("/api/settings","POST",mailSettings,{cookie});const original=globalThis.fetch;let calls=0;globalThis.fetch=async()=>{calls++;return Response.json({id:"manual-retry"});};
  try{await processLead(id,s.env,origin);assert.equal(calls,0);await s.call(`/api/leads/${id}/retry`,"POST",{},{cookie});await s.settle();assert.equal(calls,1);assert.equal(s.sqlite.prepare("SELECT email_state FROM leads WHERE id=?").get(id).email_state,"sent");}finally{globalThis.fetch=original;}
});

test("AI diagnostics distinguish credits, rate limits, authentication and access without exposing provider messages",async()=>{
  const s=await setup(configured),cookie=await s.login(),original=globalThis.fetch;
  try{
    for(const [status,code,expected] of [[429,"insufficient_quota",/insufficient_quota/],[429,"rate_limit_exceeded",/ātruma limits/],[429,undefined,/nenorādīja atpazīstamu iemeslu/],[401,"invalid_api_key",/401/],[404,"model_not_found",/modelim vai projektam/]]){
      globalThis.fetch=async()=>Response.json({error:{code,message:"Incorrect credential: sk-do-not-echo-this"}},{status});
      const response=await s.call("/api/settings/test","POST",{target:"ai"},{cookie});assert.equal(response.status,500);const body=await response.json();assert.match(body.error,expected);assert.ok(!body.error.includes("sk-do-not-echo-this"));
    }
    globalThis.fetch=async()=>{throw new TypeError("Network error with sk-do-not-echo-this");};
    const response=await s.call("/api/settings/test","POST",{target:"ai"},{cookie});const body=await response.json();assert.match(body.error,/servera savienojums/);assert.ok(!body.error.includes("sk-do-not-echo-this"));
  }finally{globalThis.fetch=original;}
});

test("current OpenAI credit and spend codes are not classified as transient rate limits",async()=>{
  const original=globalThis.fetch;
  try{for(const [code,expected] of [["credit_balance_exhausted",/kredīts ir beidzies/],["organization_spend_limit_exceeded",/tēriņu limits/],["project_spend_limit_exceeded",/tēriņu limits/],["organization_usage_limit_exceeded",/Jāpieprasa lielāks limits/],["slow_down",/ātrums pieaudzis/]]){
    globalThis.fetch=async()=>Response.json({error:{code,type:"insufficient_quota",message:"Private provider details sk-do-not-echo-this"}},{status:429});
    await assert.rejects(()=>evaluate(input(),{aiKey:"sk-runtime-test",aiModel:"gpt-4.1-mini"}),error=>{assert.match(error.message,expected);assert.ok(error.message.includes(code));assert.ok(!error.message.includes("sk-do-not-echo-this"));return true;});
  }}finally{globalThis.fetch=original;}
});

const groqEnv={AI_PROVIDER:"groq",GROQ_API_KEY:"gsk_test-private-groq",GROQ_MODEL:"openai/gpt-oss-20b"};
function groqResponse(){return Response.json({choices:[{finish_reason:"stop",message:{content:JSON.stringify({rating:"Karsts",reason:"Ir konkrēts mērķis un gatavība sākt darbu šonedēļ.",opener:"Ar kuru procesu vēlaties sākt automatizāciju šonedēļ?"})}}]});}
test("Groq evaluates new leads with its own key, strict JSON and no contact fields",async()=>{
  const s=await setup({...configured,...groqEnv}),original=globalThis.fetch,calls=[];
  globalThis.fetch=async(url,options)=>{calls.push({url:String(url),options});return String(url).includes("api.groq.com")?groqResponse():Response.json({ok:true,result:{message_id:122}});};
  try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.ai_state,"done");assert.equal(lead.ai_rating,"Karsts");assert.equal(lead.ai_model,"Groq · openai/gpt-oss-20b");assert.equal(lead.notification_state,"sent");assert.equal(calls[0].url,"https://api.groq.com/openai/v1/chat/completions");assert.equal(calls[0].options.headers.Authorization,`Bearer ${groqEnv.GROQ_API_KEY}`);const body=JSON.parse(calls[0].options.body);assert.equal(body.response_format.json_schema.strict,true);assert.equal(body.model,groqEnv.GROQ_MODEL);assert.deepEqual(Object.keys(JSON.parse(body.messages[1].content)).sort(),["company","goal","industry","monthlyRevenue"]);assert.ok(!calls.some(c=>c.url.includes("api.openai.com")));const status=await(await s.call("/api/status")).json();assert.equal(status.ai.provider,"groq");assert.equal(status.ai.lastSuccessAt,lead.ai_completed_at);}finally{globalThis.fetch=original;}
});
test("selecting Groq without a key never falls back to a saved OpenAI key",async()=>{
  const s=await setup({OPENAI_API_KEY:configured.OPENAI_API_KEY}),cookie=await s.login(),original=globalThis.fetch;let calls=0;
  await s.call("/api/settings","POST",{aiProvider:"groq",aiModel:groqEnv.GROQ_MODEL,notificationProvider:"telegram",telegramChatId:"",messengerEnabled:false},{cookie});
  globalThis.fetch=async()=>{calls++;throw new Error("No external request should be made");};
  try{const settings=await(await s.call("/api/settings","GET",undefined,{cookie})).json();assert.equal(settings.hasAiKey,true);assert.equal(settings.hasGroqKey,false);assert.equal(settings.ai,false);const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.ai_state,"blocked");assert.match(lead.ai_error,/Groq/);assert.equal(calls,0);}finally{globalThis.fetch=original;}
});
test("provider keys and models survive switching independently and secrets stay encrypted",async()=>{
  const s=await setup(configured),cookie=await s.login(),base={notificationProvider:"telegram",telegramChatId:"1234"};
  assert.equal((await s.call("/api/settings","POST",{...base,aiProvider:"groq",aiModel:groqEnv.GROQ_MODEL,groqKey:groqEnv.GROQ_API_KEY},{cookie})).status,200);
  let settings=await(await s.call("/api/settings","GET",undefined,{cookie})).json();assert.equal(settings.aiProvider,"groq");assert.equal(settings.hasGroqKey,true);assert.equal(settings.hasAiKey,true);assert.equal(settings.openaiModel,"gpt-4.1-mini");assert.ok(!JSON.stringify(settings).includes(groqEnv.GROQ_API_KEY));assert.ok(!s.sqlite.prepare("SELECT sealed FROM settings").get().sealed.includes(groqEnv.GROQ_API_KEY));
  await s.call("/api/settings","POST",{...base,aiProvider:"openai",aiModel:"gpt-4.1-mini"},{cookie});settings=await(await s.call("/api/settings","GET",undefined,{cookie})).json();assert.equal(settings.aiProvider,"openai");assert.equal(settings.groqModel,groqEnv.GROQ_MODEL);assert.equal(settings.hasGroqKey,true);
  assert.equal((await s.call("/api/settings","POST",{...base,aiProvider:"groq",aiModel:groqEnv.GROQ_MODEL,groqKey:"sk-wrong-provider"},{cookie})).status,422);
});
test("Groq quota failure preserves the lead and sends no request to OpenAI",async()=>{
  const s=await setup({...configured,...groqEnv}),original=globalThis.fetch;const hosts=[];
  globalThis.fetch=async url=>{hosts.push(new URL(url).hostname);return String(url).includes("api.groq.com")?Response.json({error:{message:"Private key gsk-do-not-echo"}},{status:429}):Response.json({ok:true,result:{message_id:123}});};
  try{const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();const lead=s.sqlite.prepare("SELECT * FROM leads WHERE id=?").get(id);assert.equal(lead.ai_state,"failed");assert.equal(lead.ai_rating,null);assert.match(lead.ai_error,/Groq kvotas limits/);assert.ok(!lead.ai_error.includes("gsk-do-not-echo"));assert.equal(lead.notification_state,"sent");assert.ok(!hosts.includes("api.openai.com"));}finally{globalThis.fetch=original;}
});
test("invalid or truncated Groq output is not accepted as an AI rating",async()=>{
  const original=globalThis.fetch,config={aiProvider:"groq",groqKey:groqEnv.GROQ_API_KEY,groqModel:groqEnv.GROQ_MODEL};
  try{for(const choice of [{finish_reason:"length",message:{content:'{"rating":"Karsts"}'}},{finish_reason:"stop",message:{content:'{"rating":"Hot","reason":"Fake reason","opener":"Fake opener"}'}},{finish_reason:"stop",message:{content:"not-json"}}]){globalThis.fetch=async()=>Response.json({choices:[choice]});await assert.rejects(()=>evaluate(input(),config),/AI Groq/);}}finally{globalThis.fetch=original;}
});

test("section saves preserve other integration settings and blank secret drafts retain saved keys",async()=>{
  const s=await setup({...configured,...groqEnv}),cookie=await s.login();
  await s.call("/api/settings","POST",{...mailSettings,messengerEnabled:true,aiProvider:"groq",aiModel:groqEnv.GROQ_MODEL},{cookie});
  assert.equal((await s.call("/api/settings","POST",{telegramToken:"",telegramChatId:"-100987654"},{cookie})).status,200);
  let config=await getIntegrations(s.env);
  assert.equal(config.telegramChatId,"-100987654");assert.equal(config.telegramToken,configured.TELEGRAM_BOT_TOKEN);assert.equal(config.aiProvider,"groq");assert.equal(config.groqModel,groqEnv.GROQ_MODEL);assert.equal(config.emailTo,mailSettings.emailTo);assert.equal(config.resendKey,mailSettings.resendKey);
  assert.equal((await s.call("/api/settings","POST",{emailEnabled:false},{cookie})).status,200);config=await getIntegrations(s.env);assert.equal(config.emailEnabled,false);assert.equal(config.telegramChatId,"-100987654");assert.equal(config.groqKey,groqEnv.GROQ_API_KEY);
  assert.equal((await s.call("/api/settings","POST",{telegramChatId:"https://t.me/+invite"},{cookie})).status,422);assert.equal((await getIntegrations(s.env)).telegramChatId,"-100987654");
});

test("Telegram group discovery excludes private chats and retired group IDs",async()=>{
  const s=await setup({...configured,TELEGRAM_CHAT_ID:"-1234"}),cookie=await s.login(),original=globalThis.fetch;
  globalThis.fetch=async url=>{assert.equal(new URL(url).searchParams.get("limit"),"100");return Response.json({ok:true,result:[
    {message:{chat:{id:321,type:"private",first_name:"Private contact"}}},
    {message:{chat:{id:-1234,type:"group",title:"Sales"},migrate_to_chat_id:-1001234}},
    {message:{chat:{id:-1001234,type:"supergroup",title:"Sales"},migrate_from_chat_id:-1234}},
    {my_chat_member:{chat:{id:-5555,type:"group",title:"Another team"},new_chat_member:{status:"administrator"}}},
    {my_chat_member:{chat:{id:-6666,type:"group",title:"Removed team"},new_chat_member:{status:"kicked"}}}
  ]});};
  try{const response=await s.call("/api/settings/telegram-chats","POST",{groupsOnly:true},{cookie});assert.equal(response.status,200);const data=await response.json();assert.equal(data.selectedChatId,"-1001234");assert.deepEqual(data.chats.map(chat=>chat.id),["-1001234","-5555"]);assert.equal(data.chats[0].type,"supergroup");}finally{globalThis.fetch=original;}
});

test("Telegram migration retries once, saves the new destination and never repeats an accepted lead",async()=>{
  const s=await setup({...configured,TELEGRAM_CHAT_ID:"-1234"}),cookie=await s.login(),original=globalThis.fetch,sends=[];
  await s.call("/api/settings","POST",{...mailSettings,messengerEnabled:true,telegramChatId:"-1234"},{cookie});
  globalThis.fetch=async(url,options)=>{
    if(String(url).includes("openai.com"))return aiResponse();if(String(url).includes("resend.com"))return Response.json({id:"email-ok"});
    const sent=JSON.parse(options.body);sends.push(sent.chat_id);
    return sent.chat_id==="-1234"?Response.json({ok:false,error_code:400,parameters:{migrate_to_chat_id:-1001234}},{status:400}):Response.json({ok:true,result:{message_id:701,chat:{id:-1001234,type:"supergroup",title:"Sharpify-Līdi"}}});
  };
  try{
    const {id}=await(await s.call("/api/leads","POST",input())).json();await s.settle();assert.deepEqual(sends,["-1234","-1001234"]);
    const saved=await getIntegrations(s.env);assert.equal(saved.telegramChatId,"-1001234");assert.equal(saved.telegramChatTitle,"Sharpify-Līdi");assert.ok(saved.telegramVerifiedAt>0);assert.equal(saved.resendKey,mailSettings.resendKey);assert.equal(saved.emailTo,mailSettings.emailTo);
    await processLead(id,s.env,origin);assert.equal(sends.length,2);assert.equal(s.sqlite.prepare("SELECT notification_message_id FROM leads WHERE id=?").get(id).notification_message_id,"701");
    await s.call("/api/leads","POST",input());await s.settle();assert.deepEqual(sends,["-1234","-1001234","-1001234"]);
    const publicText=await(await s.call("/api/status")).text();assert.ok(!publicText.includes("Sharpify-Līdi"));assert.ok(!publicText.includes("-1001234"));
  }finally{globalThis.fetch=original;}
});

test("a delayed Telegram migration cannot overwrite a destination changed in another tab",async()=>{
  const s=await setup({...configured,TELEGRAM_CHAT_ID:"-1234"}),cookie=await s.login(),original=globalThis.fetch;let sends=0;
  const initial=await getIntegrations(s.env);
  globalThis.fetch=async()=>{if(++sends===1)return Response.json({ok:false,parameters:{migrate_to_chat_id:-1001234}},{status:400});await s.call("/api/settings","POST",{telegramChatId:"-9999"},{cookie});return Response.json({ok:true,result:{message_id:702,chat:{id:-1001234,title:"Old team's upgraded group"}}});};
  try{assert.equal(await notify("Test",initial,s.env),"702");assert.equal((await getIntegrations(s.env)).telegramChatId,"-9999");}finally{globalThis.fetch=original;}
});

test("Telegram errors explain permissions, missing chats and limits without leaking provider text",async()=>{
  const s=await setup(configured),cookie=await s.login(),original=globalThis.fetch;
  try{for(const [code,description,parameters,expected]of [[403,"Forbidden secret-token",{},/tiesību.*403/],[400,"Bad Request: chat not found secret-token",{},/grupa nav atrasta/],[401,"Unauthorized secret-token",{},/atslēga nav derīga/],[429,"Too many requests secret-token",{retry_after:35},/35 sekundēm/]]){
    globalThis.fetch=async()=>Response.json({ok:false,error_code:code,description,parameters},{status:code});const response=await s.call("/api/settings/test","POST",{target:"notifications"},{cookie});assert.equal(response.status,500);const text=await response.text();assert.match(text,expected);assert.ok(!text.includes("secret-token"));
  }}finally{globalThis.fetch=original;}
});

test("Telegram webhook conflict explains manual group selection without deleting a webhook",async()=>{
  const s=await setup(configured),cookie=await s.login(),original=globalThis.fetch;let calls=0;
  globalThis.fetch=async url=>{calls++;assert.ok(String(url).includes("/getUpdates"));return Response.json({ok:false,error_code:409,description:"Conflict secret-token"},{status:409});};
  try{const response=await s.call("/api/settings/telegram-chats","POST",{groupsOnly:true},{cookie});assert.equal(response.status,500);const text=await response.text();assert.match(text,/Chat ID manuāli/);assert.ok(!text.includes("secret-token"));assert.equal(calls,1);}finally{globalThis.fetch=original;}
});

test("Telegram failed migrations stop after one retry and never record verified delivery",async()=>{
  const s=await setup({...configured,TELEGRAM_CHAT_ID:"-1234"}),original=globalThis.fetch;let calls=0;
  globalThis.fetch=async()=>{calls++;return Response.json({ok:false,error_code:400,parameters:{migrate_to_chat_id:-1001234}},{status:400});};
  try{const initial=await getIntegrations(s.env);await assert.rejects(()=>notify("Test",initial,s.env),/Telegram/);assert.equal(calls,2);const saved=await getIntegrations(s.env);assert.equal(saved.telegramChatId,"-1234");assert.equal(saved.telegramVerifiedAt,0);}finally{globalThis.fetch=original;}
});

test("changing a Telegram destination resets verification but unrelated section saves retain it",async()=>{
  const s=await setup(configured),cookie=await s.login(),original=globalThis.fetch;
  globalThis.fetch=async()=>Response.json({ok:true,result:{message_id:703,chat:{id:1234,type:"private",first_name:"Seller"}}});
  try{
    assert.equal((await s.call("/api/settings/test","POST",{target:"notifications"},{cookie})).status,200);let config=await getIntegrations(s.env);assert.ok(config.telegramVerifiedAt>0);assert.equal(config.telegramChatTitle,"Seller");
    await s.call("/api/settings","POST",{emailEnabled:false},{cookie});assert.equal((await getIntegrations(s.env)).telegramVerifiedAt,config.telegramVerifiedAt);
    await s.call("/api/settings","POST",{telegramChatId:"-1004567"},{cookie});config=await getIntegrations(s.env);assert.equal(config.telegramVerifiedAt,0);assert.equal(config.telegramChatTitle,"");
  }finally{globalThis.fetch=original;}
});

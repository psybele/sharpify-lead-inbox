import test from "node:test";
import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {readFileSync,readdirSync} from "node:fs";
import {build} from "esbuild";
import {Miniflare} from "miniflare";
import {signedProxyHeaders} from "../lib/lead-proxy.mjs";

// Run the actual API in the Workers runtime. Node fetch mocks alone cannot
// detect unsupported Request options such as redirect: "error".
test("Workers runtime reaches AI, Telegram discovery/messages and email; never follows redirects",async()=>{
  const bundle=await build({entryPoints:["lib/leads-server.ts"],bundle:true,write:false,format:"esm",platform:"browser",target:"es2022"});
  const script=bundle.outputFiles[0].text+"\nexport default {fetch:handleApi};\n";
  const assessment={rating:"Silts",reason:"Ir konkrēts izaugsmes mērķis, bet nav noteikts budžets.",opener:"Kādu pieteikumu pieaugumu vēlaties sasniegt?"};
  const calls=[],mailBodies=[];let aiCalls=0;
  async function outboundService(request){
    const url=new URL(request.url);calls.push(url.hostname+url.pathname);
    if(url.hostname==="api.openai.com"&&url.pathname==="/v1/responses"){
      if(++aiCalls===1)return Response.json({output:[{content:[{type:"output_text",text:JSON.stringify(assessment)}]}]});
      // This response passes directly into workerd. No Node fetch redirect handling.
      return new Response(null,{status:307,headers:{location:"https://unexpected.example/collect"}});
    }
    if(url.hostname==="api.telegram.org"&&url.pathname.endsWith("/getUpdates"))return Response.json({ok:true,result:[{message:{chat:{id:987654,first_name:"Runtime QA"}}}]});
    if(url.hostname==="api.telegram.org"&&url.pathname.endsWith("/sendMessage"))return Response.json({ok:true,result:{message_id:42}});
    if(url.hostname==="api.resend.com"&&url.pathname==="/emails"){mailBodies.push(await request.json());return Response.json({id:`runtime-email-${mailBodies.length}`});}
    if(url.hostname==="api.groq.com"&&url.pathname==="/openai/v1/chat/completions")return Response.json({choices:[{finish_reason:"stop",message:{content:JSON.stringify(assessment)}}]});
    throw new Error("Unexpected outbound request in isolated runtime test");
  }
  const pin="123456",secret="runtime-regression-test-secret",proxySecret="runtime-proxy-test-secret";
  const mf=new Miniflare({modules:true,script,compatibilityDate:"2026-05-15",outboundService,d1Databases:["DB"],bindings:{SESSION_SECRET:secret,LEAD_PROXY_SECRET:proxySecret,PIN_HASH:createHash("sha256").update(`${secret}:${pin}`).digest("hex")}});
  try{
    const database=await mf.getD1Database("DB");
    for(const file of readdirSync("drizzle").filter(f=>f.endsWith(".sql")).sort()){
      for(const statement of readFileSync(`drizzle/${file}`,"utf8").replaceAll("--> statement-breakpoint","").split(";").filter(v=>v.trim()))await database.prepare(statement).run();
    }
    let cookie="";
    async function request(path,data){return mf.dispatchFetch(`https://lead-inbox.test${path}`,{method:"POST",headers:{"Content-Type":"application/json",...(cookie?{cookie}:{})},body:JSON.stringify(data)});}
    const login=await request("/api/session",{pin});assert.equal(login.status,200);cookie=login.headers.get("set-cookie").split(";")[0];
    assert.equal((await request("/api/settings",{aiKey:"sk-runtime-test",aiModel:"gpt-4.1-mini",notificationProvider:"telegram",telegramToken:"123456:runtime-test",telegramChatId:"987654",emailEnabled:true,resendKey:"re_runtime-test",emailFrom:"sender@example.org",emailTo:"seller@example.org"})).status,200);
    for(const [path,data] of [["/api/settings/test",{target:"ai"}],["/api/settings/telegram-chats",{}],["/api/settings/test",{target:"notifications"}],["/api/settings/test",{target:"email"}]]){
      const response=await request(path,data);const body=await response.json();assert.equal(response.status,200,JSON.stringify({path,body}));
    }
    const redirect=await request("/api/settings/test",{target:"ai"});assert.equal(redirect.status,500);assert.match((await redirect.json()).error,/307/);
    assert.equal((await request("/api/settings",{aiProvider:"groq",groqKey:"gsk_runtime-test",aiModel:"openai/gpt-oss-20b",notificationProvider:"telegram",telegramChatId:"987654"})).status,200);
    const groq=await request("/api/settings/test",{target:"ai"});assert.equal(groq.status,200);assert.equal((await groq.json()).ok,true);
    assert.deepEqual(calls,["api.openai.com/v1/responses","api.telegram.org/bot123456:runtime-test/getUpdates","api.telegram.org/bot123456:runtime-test/sendMessage","api.resend.com/emails","api.openai.com/v1/responses","api.groq.com/openai/v1/chat/completions"]);
    const submitted=await request("/api/leads",{submissionId:crypto.randomUUID(),name:"Runtime QA",phone:"+447700900123",email:"client@example.com",company:"Runtime company",industry:"Pakalpojumi",revenue:"10 000–50 000 €",goal:"Vēlamies palielināt jauno klientu pieprasījumus."});
    assert.equal(submitted.status,201);const {id}=await submitted.json();let processed;
    for(let attempt=0;attempt<100;attempt++){processed=await database.prepare("SELECT * FROM leads WHERE id=?").bind(id).first();if(processed?.customer_email_state==="sent"&&processed?.email_state==="sent"&&processed?.notification_state==="sent")break;await new Promise(resolve=>setTimeout(resolve,20));}
    assert.equal(processed.customer_email_state,"sent");assert.equal(processed.email_state,"sent");assert.equal(processed.ai_state,"done");assert.equal(mailBodies.length,3);const confirmation=mailBodies.find(value=>value.to[0]==="client@example.com");assert.ok(confirmation.html);assert.ok(!confirmation.text.includes("/inbox"));assert.ok(confirmation.text.includes(id.slice(0,8).toUpperCase()));
    const proxyLogin=new Request("https://lead-inbox.test/api/session",{method:"POST",headers:{"content-type":"application/json",origin:"https://lead-inbox-test.vercel.app"},body:JSON.stringify({pin})});
    for(const [key,value]of Object.entries(await signedProxyHeaders(proxyLogin,proxySecret,"https://lead-inbox-test.vercel.app","198.51.100.14")))proxyLogin.headers.set(key,value);
    const proxied=await mf.dispatchFetch(proxyLogin.url,{method:proxyLogin.method,headers:Object.fromEntries(proxyLogin.headers),body:await proxyLogin.text()});assert.equal(proxied.status,200);assert.match(proxied.headers.get("set-cookie"),/HttpOnly/);
  }finally{await mf.dispose();}
});

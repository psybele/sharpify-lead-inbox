export {default} from "../lib/vercel-gateway.mjs";
